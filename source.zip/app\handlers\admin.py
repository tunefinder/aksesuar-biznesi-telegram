from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.database import Database
from app.keyboards.inline import admin_keyboard, admin_product_keyboard, admin_products_keyboard, order_keyboard
from app.services.orders import money, order_text
from app.states import ProductEdit, ProductForm

router = Router()

def is_admin(message_or_callback, admin_ids):
    return message_or_callback.from_user.id in admin_ids

@router.message(F.text == "⚙️ Admin panel")
async def panel(message: Message, admin_ids: set[int]):
    if is_admin(message, admin_ids):
        await message.answer("<b>⚙️ Admin panel</b>", reply_markup=admin_keyboard())

@router.callback_query(F.data == "admin:add")
async def add_start(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    await state.set_state(ProductForm.name)
    await callback.message.answer("Yangi mahsulot nomini kiriting:")
    await callback.answer()

@router.message(ProductForm.name)
async def add_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip()); await state.set_state(ProductForm.description)
    await message.answer("Tavsifini kiriting:")

@router.message(ProductForm.description)
async def add_description(message: Message, state: FSMContext):
    await state.update_data(description=message.text.strip()); await state.set_state(ProductForm.price)
    await message.answer("Narxini faqat raqamda kiriting (masalan: 85000):")

@router.message(ProductForm.price)
async def add_price(message: Message, state: FSMContext):
    try: price = int(message.text.replace(" ", ""))
    except (ValueError, AttributeError): return await message.answer("Narxni raqamda kiriting.")
    await state.update_data(price=price); await state.set_state(ProductForm.photo)
    await message.answer("Mahsulot rasmini yuboring yoki rasm bo'lmasa /skip yozing:")

@router.message(ProductForm.photo)
async def add_photo(message: Message, state: FSMContext):
    if message.photo: photo_id = message.photo[-1].file_id
    elif message.text == "/skip": photo_id = None
    else: return await message.answer("Rasm yuboring yoki /skip yozing.")
    await state.update_data(photo_id=photo_id); await state.set_state(ProductForm.category)
    await message.answer("Kategoriya nomini kiriting (masalan: Soatlar):")

@router.message(ProductForm.category)
async def add_category(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    await db.add_product(message.text.strip(), data['name'], data['description'], data['price'], data['photo_id'])
    await state.clear(); await message.answer("✅ Mahsulot qo'shildi.")

@router.callback_query(F.data == "admin:products")
async def product_list(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    products = await db._fetchall("SELECT * FROM products ORDER BY id DESC")
    await callback.message.answer("Tahrirlash uchun mahsulotni tanlang:", reply_markup=admin_products_keyboard(products) if products else None)
    await callback.answer()

@router.callback_query(F.data.startswith("adminproduct:"))
async def product_manage(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    product = await db.product(int(callback.data.split(":")[1]))
    if product:
        await callback.message.answer(f"<b>{product['name']}</b>\n{money(product['price'])}", reply_markup=admin_product_keyboard(product['id']))
    await callback.answer()

@router.callback_query(F.data.startswith("edit:"))
async def edit_start(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    _, product_id, field = callback.data.split(":")
    await state.update_data(product_id=int(product_id), field=field)
    await state.set_state(ProductEdit.value)
    await callback.message.answer("Yangi rasmni yuboring." if field == "photo" else "Yangi qiymatni kiriting:")
    await callback.answer()

@router.message(ProductEdit.value)
async def edit_value(message: Message, state: FSMContext, db: Database):
    data = await state.get_data(); field = data['field']
    if field == "photo":
        if not message.photo: return await message.answer("Rasm yuboring.")
        value, field = message.photo[-1].file_id, "photo_id"
    elif field == "price":
        try: value = int(message.text.replace(" ", ""))
        except (ValueError, AttributeError): return await message.answer("Narx raqam bo'lishi kerak.")
    else: value = message.text.strip()
    await db.update_product(data['product_id'], field, value)
    await state.clear(); await message.answer("✅ Mahsulot yangilandi.")

@router.callback_query(F.data.startswith("delete:"))
async def delete(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    await db.delete_product(int(callback.data.split(":")[1]))
    await callback.message.edit_text("✅ Mahsulot o'chirildi.")
    await callback.answer()

@router.callback_query(F.data == "admin:orders")
async def orders(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    rows = await db.orders()
    if not rows: await callback.message.answer("Buyurtmalar hozircha yo'q.")
    for order in rows:
        result = await db.order(order['id'])
        await callback.message.answer(order_text(*result), reply_markup=order_keyboard(order['id']))
    await callback.answer()

@router.callback_query(F.data.startswith("status:"))
async def order_status(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids): return
    _, order_id, status = callback.data.split(":", 2)
    await db.set_order_status(int(order_id), status)
    await callback.answer(f"Holat: {status}")
