import sqlite3

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.database import Database
from app.keyboards.common import main_menu
from app.keyboards.inline import (
    admin_categories_keyboard,
    admin_category_keyboard,
    admin_keyboard,
    admin_product_keyboard,
    admin_products_keyboard,
    category_delete_keyboard,
    category_select_keyboard,
    cart_keyboard,
    categories_keyboard,
    order_keyboard,
)
from app.services.orders import money, order_text
from app.states import CategoryEdit, CategoryForm, ProductEdit, ProductForm

router = Router()


def is_admin(event, admin_ids):
    return event.from_user.id in admin_ids


def category_details(category):
    status = "Aktiv ✅" if category["is_active"] else "Yashirin 🙈"
    parent = category["parent_name"] or "Asosiy"
    return (
        f"{category['emoji'] or '🗂'} <b>{category['name']}</b>\n\n"
        f"{category['description'] or 'Tavsif yo‘q'}\n\n"
        f"Holat: {status}\nOta kategoriya: {parent}\n"
        f"Mahsulotlar: {category['product_count']}\n"
        f"Ichki kategoriyalar: {category['child_count']}"
    )


async def show_categories(message, db):
    rows = await db.all_categories()
    await message.answer(
        "<b>🗂 Kategoriyalar boshqaruvi</b>",
        reply_markup=admin_categories_keyboard(rows),
    )


@router.message(CommandStart())
async def reset_start(
    message: Message, state: FSMContext, admin_ids: set[int]
):
    await state.clear()
    await message.answer(
        "Assalomu alaykum! ✨\nAksesuarlar do‘konimizga xush kelibsiz.",
        reply_markup=main_menu(message.from_user.id in admin_ids),
    )


@router.message(Command("cancel"))
async def cancel_flow(
    message: Message, state: FSMContext, admin_ids: set[int]
):
    await state.clear()
    await message.answer(
        "✅ Amal bekor qilindi.",
        reply_markup=main_menu(message.from_user.id in admin_ids),
    )


@router.message(F.text == "⚙️ Admin panel")
async def panel(message: Message, state: FSMContext, admin_ids: set[int]):
    if is_admin(message, admin_ids):
        await state.clear()
        await message.answer("<b>⚙️ Admin panel</b>", reply_markup=admin_keyboard())


@router.message(F.text == "🛍 Katalog")
async def reset_catalog(message: Message, state: FSMContext, db: Database):
    await state.clear()
    categories = await db.categories(parent_id=None, active_only=True)
    if not categories:
        return await message.answer("Katalog hozircha bo‘sh.")
    await message.answer(
        "🛍 <b>Kategoriyani tanlang:</b>",
        reply_markup=categories_keyboard(categories),
    )


@router.message(F.text == "🛒 Savatim")
async def reset_cart(message: Message, state: FSMContext, db: Database):
    await state.clear()
    items = await db.cart(message.from_user.id)
    if not items:
        return await message.answer("🛒 Savatingiz bo‘sh. Katalogdan mahsulot tanlang.")
    total = sum(item["price"] * item["quantity"] for item in items)
    lines = ["<b>🛒 Savatingiz</b>", ""]
    lines += [
        f"• {item['name']} × {item['quantity']} — {money(item['price'] * item['quantity'])}"
        for item in items
    ]
    await message.answer(
        "\n".join(lines) + f"\n\n<b>Jami: {money(total)}</b>",
        reply_markup=cart_keyboard(items),
    )


@router.callback_query(F.data == "admin:home")
async def admin_home(callback: CallbackQuery, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    await callback.message.edit_text("<b>⚙️ Admin panel</b>", reply_markup=admin_keyboard())
    await callback.answer()


@router.callback_query(F.data == "admin:categories")
async def categories_admin(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    await show_categories(callback.message, db)
    await callback.answer()


@router.callback_query(F.data == "catadmin:new")
async def category_new(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    await state.clear()
    await state.set_state(CategoryForm.name)
    await callback.message.answer("Yangi kategoriya nomini kiriting:")
    await callback.answer()


@router.callback_query(F.data.startswith("catsub:"))
async def category_sub(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    parent_id = int(callback.data.split(":")[1])
    await state.clear()
    await state.update_data(parent_id=parent_id)
    await state.set_state(CategoryForm.name)
    await callback.message.answer("Ichki kategoriya nomini kiriting:")
    await callback.answer()


@router.message(CategoryForm.name)
async def category_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(CategoryForm.description)
    await message.answer("Kategoriya tavsifini kiriting yoki /skip yozing:")


@router.message(CategoryForm.description)
async def category_description(message: Message, state: FSMContext):
    await state.update_data(description="" if message.text == "/skip" else message.text.strip())
    await state.set_state(CategoryForm.media)
    await message.answer("Kategoriya rasmi yoki emojisini yuboring. O‘tkazish uchun /skip yozing:")


@router.message(CategoryForm.media)
async def category_media(message: Message, state: FSMContext, db: Database):
    photo_id = message.photo[-1].file_id if message.photo else None
    emoji = None if photo_id or message.text == "/skip" else (message.text or "").strip()
    if not photo_id and not emoji and message.text != "/skip":
        return await message.answer("Rasm, emoji yoki /skip yuboring.")
    data = await state.get_data()
    try:
        category_id = await db.add_category(
            data["name"], data["description"], photo_id, emoji, data.get("parent_id")
        )
    except sqlite3.IntegrityError:
        return await message.answer("Bu nomdagi kategoriya mavjud. Boshqa nom kiriting.")
    await state.clear()
    category = await db.category(category_id)
    await message.answer(
        "✅ Kategoriya yaratildi.\n\n" + category_details(category),
        reply_markup=admin_category_keyboard(category_id, category["is_active"]),
    )


@router.callback_query(F.data.startswith("catadmin:"))
async def category_manage(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    category = await db.category(int(callback.data.split(":")[1]))
    if not category:
        return await callback.answer("Kategoriya topilmadi.", show_alert=True)
    markup = admin_category_keyboard(category["id"], category["is_active"])
    if category["photo_id"]:
        await callback.message.answer_photo(
            category["photo_id"], caption=category_details(category), reply_markup=markup
        )
    else:
        await callback.message.answer(category_details(category), reply_markup=markup)
    await callback.answer()


@router.callback_query(F.data.startswith("catedit:"))
async def category_edit_start(
    callback: CallbackQuery, state: FSMContext, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    _, category_id, field = callback.data.split(":")
    await state.update_data(category_id=int(category_id), field=field)
    await state.set_state(CategoryEdit.value)
    prompts = {
        "name": "Yangi nomni kiriting:",
        "description": "Yangi tavsifni kiriting:",
        "emoji": "Yangi emojini kiriting yoki olib tashlash uchun /clear yozing:",
        "photo": "Yangi rasmni yuboring yoki olib tashlash uchun /clear yozing:",
    }
    await callback.message.answer(prompts[field])
    await callback.answer()


@router.message(CategoryEdit.value)
async def category_edit_value(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    field = data["field"]
    if field == "photo":
        if message.text == "/clear":
            value, field = None, "photo_id"
        elif message.photo:
            value, field = message.photo[-1].file_id, "photo_id"
        else:
            return await message.answer("Rasm yoki /clear yuboring.")
    else:
        value = None if message.text == "/clear" else message.text.strip()
    try:
        await db.update_category(data["category_id"], field, value)
    except sqlite3.IntegrityError:
        return await message.answer("Bu nom band. Boshqa nom kiriting.")
    await state.clear()
    await message.answer("✅ Kategoriya yangilandi.")


@router.callback_query(F.data.startswith("cattoggle:"))
async def category_toggle(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    category_id = int(callback.data.split(":")[1])
    await db.toggle_category(category_id)
    category = await db.category(category_id)
    await callback.message.edit_text(
        category_details(category),
        reply_markup=admin_category_keyboard(category_id, category["is_active"]),
    )
    await callback.answer("Holat o‘zgartirildi")


@router.callback_query(F.data.startswith("catmove:"))
async def category_move(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    _, category_id, direction = callback.data.split(":")
    await db.move_category(int(category_id), int(direction))
    await callback.answer("Tartib yangilandi")


@router.callback_query(F.data.startswith("catproducts:"))
async def category_products_move(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    source_id = int(callback.data.split(":")[1])
    categories = await db.all_categories()
    await callback.message.answer(
        "Barcha mahsulotlar ko‘chiriladigan kategoriyani tanlang:",
        reply_markup=category_select_keyboard(categories, f"catmoveto:{source_id}", source_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("catmoveto:"))
async def category_products_move_to(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    _, source_id, target_id = callback.data.split(":")
    await db.move_all_products(int(source_id), int(target_id))
    await callback.message.edit_text("✅ Mahsulotlar boshqa kategoriyaga ko‘chirildi.")
    await callback.answer()


@router.callback_query(F.data.startswith("catdelete:"))
async def category_delete_start(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    category_id = int(callback.data.split(":")[1])
    category = await db.category(category_id)
    if category["child_count"]:
        return await callback.answer(
            "Avval ichki kategoriyalarni ko‘chiring yoki o‘chiring.", show_alert=True
        )
    text = f"“{category['name']}” kategoriyasini o‘chirishni tasdiqlang."
    if category["product_count"]:
        text += f"\n\nIchida {category['product_count']} ta mahsulot bor. Amalni tanlang:"
    await callback.message.answer(
        text,
        reply_markup=category_delete_keyboard(category_id, bool(category["product_count"])),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("catdelmove:"))
async def category_delete_move(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    source_id = int(callback.data.split(":")[1])
    categories = await db.all_categories()
    await callback.message.edit_text(
        "Mahsulotlarni qaysi kategoriyaga ko‘chiramiz?",
        reply_markup=category_select_keyboard(categories, f"catdelto:{source_id}", source_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("catdelto:"))
async def category_delete_move_to(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    _, source_id, target_id = callback.data.split(":")
    await db.move_all_products(int(source_id), int(target_id))
    await db.delete_category(int(source_id))
    await callback.message.edit_text("✅ Mahsulotlar ko‘chirildi va kategoriya o‘chirildi.")
    await callback.answer()


@router.callback_query(F.data.startswith("catdelall:"))
async def category_delete_all(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    await db.delete_category(int(callback.data.split(":")[1]), delete_products=True)
    await callback.message.edit_text("✅ Kategoriya mahsulotlari bilan birga o‘chirildi.")
    await callback.answer()


@router.callback_query(F.data.startswith("catdelconfirm:"))
async def category_delete_confirm(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    await db.delete_category(int(callback.data.split(":")[1]))
    await callback.message.edit_text("✅ Kategoriya o‘chirildi.")
    await callback.answer()


@router.callback_query(F.data == "admin:add")
async def add_start(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    await state.clear()
    await state.set_state(ProductForm.name)
    await callback.message.answer("Yangi mahsulot nomini kiriting:")
    await callback.answer()


@router.message(ProductForm.name)
async def add_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(ProductForm.description)
    await message.answer("Tavsifini kiriting:")


@router.message(ProductForm.description)
async def add_description(message: Message, state: FSMContext):
    await state.update_data(description=message.text.strip())
    await state.set_state(ProductForm.price)
    await message.answer("Narxini faqat raqamda kiriting:")


@router.message(ProductForm.price)
async def add_price(message: Message, state: FSMContext):
    try:
        price = int(message.text.replace(" ", ""))
    except (ValueError, AttributeError):
        return await message.answer("Narxni raqamda kiriting.")
    await state.update_data(price=price)
    await state.set_state(ProductForm.photo)
    await message.answer("Mahsulot rasmini yuboring yoki /skip yozing:")


@router.message(ProductForm.photo)
async def add_photo(message: Message, state: FSMContext, db: Database):
    if message.photo:
        photo_id = message.photo[-1].file_id
    elif message.text == "/skip":
        photo_id = None
    else:
        return await message.answer("Rasm yuboring yoki /skip yozing.")
    await state.update_data(photo_id=photo_id)
    await state.set_state(ProductForm.category)
    categories = await db.all_categories()
    await message.answer(
        "Mahsulot kategoriyasini tanlang:",
        reply_markup=category_select_keyboard(categories, "prodnewcat"),
    )


@router.callback_query(ProductForm.category, F.data.startswith("prodnewcat:"))
async def add_category(callback: CallbackQuery, state: FSMContext, db: Database):
    data = await state.get_data()
    await db.add_product(
        int(callback.data.split(":")[1]),
        data["name"],
        data["description"],
        data["price"],
        data["photo_id"],
    )
    await state.clear()
    await callback.message.edit_text("✅ Mahsulot qo‘shildi.")
    await callback.answer()


@router.callback_query(F.data == "admin:products")
async def product_list(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    products = await db.products()
    await callback.message.answer(
        "Tahrirlash uchun mahsulotni tanlang:",
        reply_markup=admin_products_keyboard(products) if products else None,
    )
    await callback.answer()


@router.callback_query(F.data.startswith("adminproduct:"))
async def product_manage(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    product = await db.product(int(callback.data.split(":")[1]))
    if product:
        await callback.message.answer(
            f"<b>{product['name']}</b>\n{money(product['price'])}\n🗂 {product['category_name']}",
            reply_markup=admin_product_keyboard(product["id"]),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("prodcat:"))
async def product_category_start(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    product_id = int(callback.data.split(":")[1])
    await callback.message.answer(
        "Yangi kategoriyani tanlang:",
        reply_markup=category_select_keyboard(
            await db.all_categories(), f"prodcatto:{product_id}"
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("prodcatto:"))
async def product_category_save(
    callback: CallbackQuery, db: Database, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    _, product_id, category_id = callback.data.split(":")
    await db.update_product(int(product_id), "category_id", int(category_id))
    await callback.message.edit_text("✅ Mahsulot kategoriyasi o‘zgartirildi.")
    await callback.answer()


@router.callback_query(F.data.startswith("edit:"))
async def edit_start(
    callback: CallbackQuery, state: FSMContext, admin_ids: set[int]
):
    if not is_admin(callback, admin_ids):
        return
    _, product_id, field = callback.data.split(":")
    await state.update_data(product_id=int(product_id), field=field)
    await state.set_state(ProductEdit.value)
    await callback.message.answer(
        "Yangi rasmni yuboring." if field == "photo" else "Yangi qiymatni kiriting:"
    )
    await callback.answer()


@router.message(ProductEdit.value)
async def edit_value(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    field = data["field"]
    if field == "photo":
        if not message.photo:
            return await message.answer("Rasm yuboring.")
        value, field = message.photo[-1].file_id, "photo_id"
    elif field == "price":
        try:
            value = int(message.text.replace(" ", ""))
        except (ValueError, AttributeError):
            return await message.answer("Narx raqam bo‘lishi kerak.")
    else:
        value = message.text.strip()
    await db.update_product(data["product_id"], field, value)
    await state.clear()
    await message.answer("✅ Mahsulot yangilandi.")


@router.callback_query(F.data.startswith("delete:"))
async def delete(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    await db.delete_product(int(callback.data.split(":")[1]))
    await callback.message.edit_text("✅ Mahsulot o‘chirildi.")
    await callback.answer()


@router.callback_query(F.data == "admin:orders")
async def orders(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    rows = await db.orders()
    if not rows:
        await callback.message.answer("Buyurtmalar hozircha yo‘q.")
    for order in rows:
        result = await db.order(order["id"])
        await callback.message.answer(
            order_text(*result), reply_markup=order_keyboard(order["id"])
        )
    await callback.answer()


@router.callback_query(F.data.startswith("status:"))
async def order_status(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not is_admin(callback, admin_ids):
        return
    _, order_id, status = callback.data.split(":", 2)
    await db.set_order_status(int(order_id), status)
    await callback.answer(f"Holat: {status}")
