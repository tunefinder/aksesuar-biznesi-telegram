"""Aksesuarlar do'koni Telegram bot paketi."""
