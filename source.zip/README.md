# Aksesuar biznesi — Telegram bot

Aiogram 3, SQLite va Python asosidagi aksessuarlar do'koni boti. Xaridorlar katalogni ko'radi, savat orqali buyurtma qiladi; admin mahsulotlar va buyurtmalarni boshqaradi.

## Imkoniyatlar

- Kategoriyalar va rasmli mahsulotlar katalogi
- Savat, mahsulot miqdori, o'chirish va buyurtma rasmiylashtirish
- Ism, telefon va manzilni yig'ish
- Yangi buyurtmani barcha adminlarga yuborish
- Admin panel: mahsulot qo'shish, tahrirlash, o'chirish; buyurtma holatini belgilash

## Windows CMD orqali ishga tushirish

Python 3.11 yoki yangi versiyasi o'rnatilgan bo'lsin.

```cmd
cd /d "C:\Users\yuldo\Desktop\Aksesuar biznesi"
py -3.12 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
notepad .env
python main.py
```

`.env` ichida `BOT_TOKEN` qiymatini @BotFather bergan token bilan, `ADMIN_IDS` qiymatini esa o'zingizning raqamli Telegram ID'ingiz bilan almashtiring. ID olish uchun @userinfobot kabi botdan foydalanish mumkin.

## Admin panel

Admin `/start` yuborgach, bosh menyuda `⚙️ Admin panel` chiqadi. Mahsulot yaratishda rasmni Telegramga fayl sifatida yubormang, odatiy **Photo** qilib yuboring. Bot uning `file_id` qiymatini saqlaydi, shuning uchun rasm keyinchalik yana yuklanmaydi.

## Tuzilma

```
app/
  handlers/       # mijoz va admin oqimlari
  keyboards/      # reply va inline tugmalar
  services/       # buyurtma matni kabi yordamchilar
  config.py       # .env sozlamalari
  database.py     # SQLite qatlami
  states.py       # FSM holatlari
data/             # avtomatik yaratiladigan SQLite bazasi
main.py
```
