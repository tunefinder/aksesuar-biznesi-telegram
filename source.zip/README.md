# Aksesuar biznesi — Telegram bot

Aiogram 3, SQLite va Python asosidagi aksessuarlar do'koni boti. Xaridorlar katalogni ko'radi, savat orqali buyurtma qiladi; admin mahsulotlar va buyurtmalarni boshqaradi.

## Professional imkoniyatlar

- Dinamik kategoriya va ichki kategoriyalar
- Rang, telefon modeli, SKU, individual narx va ombor qoldig'iga ega variantlar
- Qidiruv, narx va ombor filtrlari, sevimlilar, buyurtmalar tarixi
- Noyob `AX-000001` formatidagi buyurtma raqami
- Buyurtma statusi va to'lov holati bo'yicha avtomatik xabar
- Promokod, bonus va referal tizimi
- Admin boshqaradigan yetkazib berish hududlari va tariflari
- Naqd, karta va chek orqali to'lov
- Super admin, operator, omborchi va kuryer rollari
- Sotuv, daromad, o'rtacha chek, top mahsulotlar va ombor statistikasi
- Mahsulot va variantlarni CSV import/eksport qilish
- Admin harakatlari va dastur xatolarini SQLite bazaga yozish
- Har 6 soatda avtomatik backup, 14 kunlik saqlash

## Modullar

```text
app/
  domain/          # rollar, statuslar va biznes konstantalari
  handlers/        # mijoz, do'kon, admin va professional admin oqimlari
  keyboards/       # Telegram klaviaturalari
  middleware/      # admin audit
  services/        # katalog, bonus, CSV, backup, ruxsat va hisobotlar
  database.py      # ma'lumotlarga kirish fasadi
  schema.py        # xavfsiz SQLite schema va migratsiyalar
```

Xodimlar `/admin` orqali roliga mos panelni ochadi. Yarim qolgan
formani `/cancel` buyrug'i bilan xavfsiz bekor qilish mumkin.

## Imkoniyatlar

- Kategoriyalar va rasmli mahsulotlar katalogi
- Savat, mahsulot miqdori, o'chirish va buyurtma rasmiylashtirish
- Ism, telefon va manzilni yig'ish
- Yangi buyurtmani barcha adminlarga yuborish
- Admin panel: mahsulot qo'shish, tahrirlash, o'chirish; buyurtma holatini belgilash

## Windows CMD orqali ishga tushirish

Python 3.11 yoki yangi versiyasi o'rnatilgan bo'lsin.

```cmd
cd /d "C:\Users\yuldo\Desktop\Aksesuar biznesi"
py -3.12 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
notepad .env
python main.py
```

`.env` ichida `BOT_TOKEN` qiymatini @BotFather bergan token bilan, `ADMIN_IDS` qiymatini esa o'zingizning raqamli Telegram ID'ingiz bilan almashtiring. ID olish uchun @userinfobot kabi botdan foydalanish mumkin.

## Admin panel

Admin `/start` yuborgach, bosh menyuda `⚙️ Admin panel` chiqadi. Mahsulot yaratishda rasmni Telegramga fayl sifatida yubormang, odatiy **Photo** qilib yuboring. Bot uning `file_id` qiymatini saqlaydi, shuning uchun rasm keyinchalik yana yuklanmaydi.

## Tuzilma

```
app/
  handlers/       # mijoz va admin oqimlari
  keyboards/      # reply va inline tugmalar
  services/       # buyurtma matni kabi yordamchilar
  config.py       # .env sozlamalari
  database.py     # SQLite qatlami
  states.py       # FSM holatlari
data/             # avtomatik yaratiladigan SQLite bazasi
main.py
```
