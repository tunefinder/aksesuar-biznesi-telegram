from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.database import Database
from app.keyboards.common import contact_keyboard, main_menu
from app.keyboards.inline import cart_keyboard, categories_keyboard, order_keyboard, product_keyboard, products_keyboard
from app.services.orders import money, order_text
from app.states import Checkout

router = Router()

def cart_text(items):
    if not items:
        return "🛒 Savatingiz bo'sh. Katalogdan mahsulot tanlang."
    total = sum(item['price'] * item['quantity'] for item in items)
    lines = ["<b>🛒 Savatingiz</b>", ""]
    lines += [f"• {i['name']} × {i['quantity']} — {money(i['price'] * i['quantity'])}" for i in items]
    return "\n".join(lines) + f"\n\n<b>Jami: {money(total)}</b>"

async def show_catalog(message: Message, db: Database):
    await message.answer("🛍 <b>Kategoriyani tanlang:</b>", reply_markup=categories_keyboard(await db.categories()))

@router.message(F.text == "/start")
async def start(message: Message, db: Database, admin_ids: set[int]):
    await message.answer("Assalomu alaykum! ✨\nAksesuarlar do'konimizga xush kelibsiz.", reply_markup=main_menu(message.from_user.id in admin_ids))

@router.message(F.text == "🛍 Katalog")
async def catalog_message(message: Message, db: Database):
    await show_catalog(message, db)

@router.callback_query(F.data == "catalog")
async def catalog_callback(callback: CallbackQuery, db: Database):
    await callback.message.edit_text("🛍 <b>Kategoriyani tanlang:</b>", reply_markup=categories_keyboard(await db.categories()))
    await callback.answer()

@router.callback_query(F.data.startswith("cat:"))
async def category(callback: CallbackQuery, db: Database):
    products = await db.products_by_category(int(callback.data.split(":")[1]))
    text = "Mahsulotni tanlang:" if products else "Bu kategoriyada hozircha mahsulot yo'q."
    await callback.message.edit_text(text, reply_markup=products_keyboard(products) if products else None)
    await callback.answer()

@router.callback_query(F.data.startswith("product:"))
async def product(callback: CallbackQuery, db: Database):
    item = await db.product(int(callback.data.split(":")[1]))
    if not item:
        return await callback.answer("Mahsulot topilmadi", show_alert=True)
    caption = f"<b>{item['name']}</b>\n\n{item['description']}\n\n💳 <b>Narxi: {money(item['price'])}</b>"
    if item['photo_id']:
        await callback.message.answer_photo(item['photo_id'], caption=caption, reply_markup=product_keyboard(item['id']))
    else:
        await callback.message.answer(caption, reply_markup=product_keyboard(item['id']))
    await callback.answer()

@router.callback_query(F.data.startswith("addcart:"))
async def add_cart(callback: CallbackQuery, db: Database):
    await db.add_to_cart(callback.from_user.id, int(callback.data.split(":")[1]))
    await callback.answer("Savatga qo'shildi ✅")

@router.message(F.text == "🛒 Savatim")
async def cart(message: Message, db: Database):
    items = await db.cart(message.from_user.id)
    await message.answer(cart_text(items), reply_markup=cart_keyboard(items) if items else None)

@router.callback_query(F.data.startswith("remove:"))
async def remove_cart(callback: CallbackQuery, db: Database):
    await db.remove_cart_item(callback.from_user.id, int(callback.data.split(":")[1]))
    items = await db.cart(callback.from_user.id)
    await callback.message.edit_text(cart_text(items), reply_markup=cart_keyboard(items) if items else None)
    await callback.answer("O'chirildi")

@router.callback_query(F.data == "checkout")
async def checkout(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Checkout.name)
    await callback.message.answer("Buyurtma uchun ismingizni kiriting:")
    await callback.answer()

@router.message(Checkout.name)
async def checkout_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(Checkout.phone)
    await message.answer("Telefon raqamingizni yuboring yoki kiriting:", reply_markup=contact_keyboard())

@router.message(Checkout.phone)
async def checkout_phone(message: Message, state: FSMContext):
    phone = message.contact.phone_number if message.contact else (message.text or "").strip()
    if len(phone) < 7:
        return await message.answer("Telefon raqamini to'g'ri kiriting.")
    await state.update_data(phone=phone)
    await state.set_state(Checkout.address)
    await message.answer("Yetkazib berish manzilini yozing:")

@router.message(Checkout.address)
async def checkout_address(message: Message, state: FSMContext, db: Database, bot, admin_ids: set[int]):
    data = await state.get_data()
    result = await db.create_order(message.from_user.id, data['name'], data['phone'], message.text.strip())
    if not result:
        await state.clear()
        return await message.answer("Savatingiz bo'sh ekan.")
    order, items = result
    text = order_text(order, items)
    for admin_id in admin_ids:
        await bot.send_message(admin_id, text, reply_markup=order_keyboard(order['id']))
    await state.clear()
    await message.answer("✅ Buyurtmangiz qabul qilindi! Tez orada siz bilan bog'lanamiz.", reply_markup=main_menu(message.from_user.id in admin_ids))
