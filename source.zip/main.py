import asyncio
import logging
import traceback
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode

from app.config import load_config
from app.database import Database
from app.handlers import admin, admin_pro, shop, user
from app.middleware.audit import AdminAuditMiddleware
from app.services.backup import backup_loop


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    config = load_config()
    db = Database(config.database_path)
    await db.connect()
    admin_pro.configure_staff(await db.staff())
    session = AiohttpSession()
    bot = Bot(config.bot_token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp["db"] = db
    dp["admin_ids"] = config.admin_ids
    admin.router.callback_query.outer_middleware(AdminAuditMiddleware())
    admin_pro.router.callback_query.outer_middleware(AdminAuditMiddleware())
    dp.include_router(shop.router)
    dp.include_router(admin_pro.router)
    dp.include_router(admin.router)
    dp.include_router(user.router)

    @dp.error()
    async def save_error(event):
        exception = event.exception
        logging.exception("Telegram update ishlovida xato", exc_info=exception)
        try:
            await db._execute(
                """INSERT INTO error_logs(level,source,message,traceback)
                   VALUES(?,?,?,?)""",
                (
                    "ERROR",
                    "aiogram",
                    str(exception),
                    "".join(
                        traceback.format_exception(
                            type(exception), exception, exception.__traceback__
                        )
                    ),
                ),
            )
        except Exception:
            logging.exception("Xatoni bazaga yozib bo‘lmadi")
        try:
            update = event.update
            message = update.message or (
                update.callback_query.message if update.callback_query else None
            )
            if update.callback_query:
                await update.callback_query.answer(
                    "Amal bajarilmadi. Qayta urinib ko‘ring.", show_alert=True
                )
            if message:
                await message.answer(
                    "⚠️ Amal vaqtida vaqtinchalik xato yuz berdi.\n"
                    "Menyuni yangilash uchun /start yuboring."
                )
        except Exception:
            logging.exception("Foydalanuvchiga xato xabarini yuborib bo‘lmadi")
        return True

    await bot.delete_webhook(drop_pending_updates=True)
    logging.info("Bot ishga tushdi va xabarlarni kutmoqda.")
    backup_task = asyncio.create_task(
        backup_loop(config.database_path, config.database_path.parent / "backups")
    )
    try:
        await dp.start_polling(bot)
    finally:
        backup_task.cancel()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
