import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramNetworkError

from app.config import load_config
from app.database import Database
from app.handlers import admin, user
from app.powershell_session import PowerShellSession


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    config = load_config()
    db = Database(config.database_path)
    await db.connect()
    # Lokal Windows tarmog'ida PowerShell transporti kerak; hostingda aiohttp ishlaydi.
    session = PowerShellSession() if os.name == "nt" else AiohttpSession()
    bot = Bot(config.bot_token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp["db"] = db
    dp["admin_ids"] = config.admin_ids
    dp.include_router(admin.router)
    dp.include_router(user.router)
    while True:
        try:
            await bot.delete_webhook(drop_pending_updates=True)
            logging.info("Bot ishga tushdi va xabarlarni kutmoqda.")
            await dp.start_polling(bot)
        except TelegramNetworkError as error:
            logging.warning("Telegram bilan ulanish uzildi: %s. 15 soniyadan so'ng qayta uriniladi.", error)
            await asyncio.sleep(15)


if __name__ == "__main__":
    asyncio.run(main())
