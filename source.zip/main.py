import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode

from app.config import load_config
from app.database import Database
from app.handlers import admin, user


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    config = load_config()
    db = Database(config.database_path)
    await db.connect()
    session = AiohttpSession()
    bot = Bot(config.bot_token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp["db"] = db
    dp["admin_ids"] = config.admin_ids
    dp.include_router(admin.router)
    dp.include_router(user.router)
    await bot.delete_webhook(drop_pending_updates=True)
    logging.info("Bot ishga tushdi va xabarlarni kutmoqda.")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
