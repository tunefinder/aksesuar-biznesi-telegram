from aiogram.fsm.state import State, StatesGroup


class Checkout(StatesGroup):
    name = State()
    phone = State()
    address = State()


class ProductForm(StatesGroup):
    name = State()
    description = State()
    price = State()
    photo = State()
    category = State()


class ProductEdit(StatesGroup):
    value = State()


class CategoryForm(StatesGroup):
    name = State()
    description = State()
    media = State()
    parent = State()


class CategoryEdit(StatesGroup):
    value = State()
