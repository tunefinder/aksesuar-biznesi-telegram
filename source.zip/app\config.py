from dataclasses import dataclass
from pathlib import Path
import os

from dotenv import load_dotenv


@dataclass(frozen=True)
class Config:
    bot_token: str
    admin_ids: set[int]
    database_path: Path


def load_config() -> Config:
    # Loyiha papkasidagi .env qiymatlari Windows global muhitidan ustun turadi.
    load_dotenv(override=True)
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("BOT_TOKEN .env faylida to'g'ri sozlanmagan.")
    raw_admins = os.getenv("ADMIN_IDS", "")
    try:
        admin_ids = {int(value.strip()) for value in raw_admins.split(",") if value.strip()}
    except ValueError as error:
        raise RuntimeError("ADMIN_IDS faqat Telegram ID raqamlaridan iborat bo'lishi kerak.") from error
    if not admin_ids:
        raise RuntimeError("Kamida bitta ADMIN_IDS qiymatini kiriting.")
    database_path = Path(os.getenv("DATABASE_PATH", "data/accessories.db"))
    return Config(token, admin_ids, database_path)
