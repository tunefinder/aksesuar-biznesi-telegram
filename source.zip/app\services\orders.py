def money(amount: int) -> str:
    return f"{amount:,}".replace(",", " ") + " so'm"


def order_text(order, items) -> str:
    lines = [f"<b>Yangi buyurtma #{order['id']}</b>", "", f"👤 {order['customer_name']}", f"📱 {order['phone']}", f"📍 {order['address']}", "", "<b>Mahsulotlar:</b>"]
    lines.extend(f"• {item['product_name']} × {item['quantity']} — {money(item['price'] * item['quantity'])}" for item in items)
    lines.extend(["", f"<b>Jami: {money(order['total'])}</b>", f"Holati: {order['status']}"])
    return "\n".join(lines)
