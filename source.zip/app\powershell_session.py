"""Aiogram transporti: Windows PowerShell HTTPS tarmog'idan foydalanadi.

Ba'zi Windows tarmoqlarida Python jarayonining to'g'ridan-to'g'ri HTTPS ulanishi
cheklanadi, lekin tizimning PowerShell/.NET transporti ishlaydi.
"""

import asyncio
import os
from collections.abc import AsyncGenerator
from urllib.parse import urlencode

from aiogram.client.session.base import BaseSession
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods.base import TelegramMethod, TelegramType
from aiogram.types import InputFile


class PowerShellSession(BaseSession):
    _script = (
        "$r=Invoke-WebRequest -UseBasicParsing -Uri $env:TG_URL -Method Post "
        "-ContentType 'application/x-www-form-urlencoded' -Body $env:TG_BODY "
        "-TimeoutSec ([int]$env:TG_TIMEOUT);[Console]::Out.Write($r.Content)"
    )

    async def close(self) -> None:
        return None

    async def make_request(self, bot, method: TelegramMethod[TelegramType], timeout: int | None = None) -> TelegramType:
        files: dict[str, InputFile] = {}
        values: dict[str, str] = {}
        for key, value in method.model_dump(warnings=False).items():
            prepared = self.prepare_value(value, bot=bot, files=files)
            if prepared:
                values[key] = prepared
        if files:
            raise TelegramNetworkError(method=method, message="Bu transport yangi fayl yuklashni qo'llamaydi.")

        request_timeout = timeout or int(self.timeout)
        environment = os.environ.copy()
        environment.update({
            "TG_URL": self.api.api_url(token=bot.token, method=method),
            "TG_BODY": urlencode(values),
            "TG_TIMEOUT": str(request_timeout),
        })
        process = await asyncio.create_subprocess_exec(
            "powershell.exe", "-NoProfile", "-NonInteractive", "-Command", self._script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=environment,
        )
        try:
            output, errors = await asyncio.wait_for(process.communicate(), timeout=request_timeout + 15)
        except TimeoutError as error:
            process.kill()
            await process.wait()
            raise TelegramNetworkError(method=method, message="PowerShell so'rovi timeout bo'ldi.") from error
        if process.returncode != 0:
            raise TelegramNetworkError(method=method, message=errors.decode("utf-8", "replace")[-500:])
        if not output.strip():
            raise TelegramNetworkError(method=method, message="PowerShell Telegram serveridan bo'sh javob oldi.")
        response = self.check_response(bot=bot, method=method, status_code=200, content=output.decode("utf-8"))
        return response.result

    async def stream_content(self, url: str, headers=None, timeout: int = 30, chunk_size: int = 65536, raise_for_status: bool = True) -> AsyncGenerator[bytes, None]:
        raise NotImplementedError("Fayl yuklash ushbu botda ishlatilmaydi.")
        yield b""
