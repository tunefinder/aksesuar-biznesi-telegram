from pathlib import Path

import aiosqlite


class Database:
    def __init__(self, path: Path):
        self.path = path

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            await db.executescript(
                """
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE
                );
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    price INTEGER NOT NULL CHECK(price >= 0),
                    photo_id TEXT
                );
                CREATE TABLE IF NOT EXISTS carts (
                    user_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
                    quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0),
                    PRIMARY KEY(user_id, product_id)
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    customer_name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    address TEXT NOT NULL,
                    total INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Yangi',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS order_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                    product_name TEXT NOT NULL,
                    price INTEGER NOT NULL,
                    quantity INTEGER NOT NULL
                );
                """
            )
            columns = {
                row[1] for row in await (await db.execute("PRAGMA table_info(categories)")).fetchall()
            }
            migrations = {
                "description": "ALTER TABLE categories ADD COLUMN description TEXT NOT NULL DEFAULT ''",
                "photo_id": "ALTER TABLE categories ADD COLUMN photo_id TEXT",
                "emoji": "ALTER TABLE categories ADD COLUMN emoji TEXT",
                "is_active": "ALTER TABLE categories ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1",
                "sort_order": "ALTER TABLE categories ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0",
                "parent_id": "ALTER TABLE categories ADD COLUMN parent_id INTEGER REFERENCES categories(id) ON DELETE RESTRICT",
            }
            for column, statement in migrations.items():
                if column not in columns:
                    await db.execute(statement)
            await db.executemany(
                "INSERT OR IGNORE INTO categories(name, sort_order) VALUES(?, ?)",
                [
                    ("Soatlar", 10),
                    ("Zargarlik buyumlari", 20),
                    ("Sumkalar", 30),
                    ("Ko'zoynaklar", 40),
                ],
            )
            await db.execute(
                "UPDATE categories SET sort_order=id*10 WHERE sort_order=0"
            )
            await db.commit()

    async def _fetchall(self, query, params=()):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("PRAGMA foreign_keys = ON")
            async with db.execute(query, params) as cursor:
                return await cursor.fetchall()

    async def _fetchone(self, query, params=()):
        rows = await self._fetchall(query, params)
        return rows[0] if rows else None

    async def _execute(self, query, params=()):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cursor = await db.execute(query, params)
            await db.commit()
            return cursor.lastrowid

    async def categories(self, parent_id=None, active_only=True):
        where = ["parent_id IS ?" ]
        params = [parent_id]
        if active_only:
            where.append("is_active=1")
        return await self._fetchall(
            f"""SELECT c.*,
                       (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) product_count,
                       (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
                FROM categories c
                WHERE {' AND '.join(where)}
                ORDER BY sort_order, id""",
            params,
        )

    async def all_categories(self):
        return await self._fetchall(
            """SELECT c.*, p.name parent_name,
                      (SELECT COUNT(*) FROM products pr WHERE pr.category_id=c.id) product_count,
                      (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
               FROM categories c LEFT JOIN categories p ON p.id=c.parent_id
               ORDER BY COALESCE(c.parent_id, c.id), c.parent_id IS NOT NULL, c.sort_order, c.id"""
        )

    async def category(self, category_id: int):
        return await self._fetchone(
            """SELECT c.*, p.name parent_name,
                      (SELECT COUNT(*) FROM products pr WHERE pr.category_id=c.id) product_count,
                      (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
               FROM categories c LEFT JOIN categories p ON p.id=c.parent_id
               WHERE c.id=?""",
            (category_id,),
        )

    async def add_category(self, name, description="", photo_id=None, emoji=None, parent_id=None):
        row = await self._fetchone(
            "SELECT COALESCE(MAX(sort_order), 0)+10 next_order FROM categories WHERE parent_id IS ?",
            (parent_id,),
        )
        return await self._execute(
            """INSERT INTO categories(name,description,photo_id,emoji,parent_id,sort_order)
               VALUES(?,?,?,?,?,?)""",
            (name.strip(), description.strip(), photo_id, emoji, parent_id, row["next_order"]),
        )

    async def update_category(self, category_id: int, field: str, value):
        allowed = {"name", "description", "photo_id", "emoji", "parent_id", "is_active"}
        if field not in allowed:
            raise ValueError("Noto'g'ri kategoriya maydoni")
        await self._execute(f"UPDATE categories SET {field}=? WHERE id=?", (value, category_id))

    async def toggle_category(self, category_id: int):
        await self._execute(
            "UPDATE categories SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",
            (category_id,),
        )

    async def move_category(self, category_id: int, direction: int):
        category = await self.category(category_id)
        if not category:
            return
        operator, order = ("<", "DESC") if direction < 0 else (">", "ASC")
        sibling = await self._fetchone(
            f"""SELECT * FROM categories WHERE parent_id IS ? AND sort_order {operator} ?
                ORDER BY sort_order {order}, id {order} LIMIT 1""",
            (category["parent_id"], category["sort_order"]),
        )
        if not sibling:
            return
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE categories SET sort_order=? WHERE id=?",
                (sibling["sort_order"], category_id),
            )
            await db.execute(
                "UPDATE categories SET sort_order=? WHERE id=?",
                (category["sort_order"], sibling["id"]),
            )
            await db.commit()

    async def delete_category(self, category_id: int, delete_products=False):
        category = await self.category(category_id)
        if not category:
            return False
        if category["child_count"]:
            raise ValueError("Ichki kategoriyalar mavjud")
        if category["product_count"] and not delete_products:
            raise ValueError("Mahsulotlar mavjud")
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            if delete_products:
                await db.execute("DELETE FROM products WHERE category_id=?", (category_id,))
            await db.execute("DELETE FROM categories WHERE id=?", (category_id,))
            await db.commit()
        return True

    async def products_by_category(self, category_id: int):
        return await self._fetchall(
            "SELECT * FROM products WHERE category_id=? ORDER BY id DESC", (category_id,)
        )

    async def products(self):
        return await self._fetchall(
            "SELECT p.*, c.name category_name FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC"
        )

    async def product(self, product_id: int):
        return await self._fetchone(
            "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?",
            (product_id,),
        )

    async def add_product(self, category_id: int, name: str, description: str, price: int, photo_id: str | None):
        await self._execute(
            "INSERT INTO products(category_id,name,description,price,photo_id) VALUES(?,?,?,?,?)",
            (category_id, name, description, price, photo_id),
        )

    async def update_product(self, product_id: int, field: str, value):
        allowed = {"name", "description", "price", "photo_id", "category_id"}
        if field not in allowed:
            raise ValueError("Noto'g'ri ustun")
        await self._execute(f"UPDATE products SET {field}=? WHERE id=?", (value, product_id))

    async def move_all_products(self, source_id: int, target_id: int):
        await self._execute(
            "UPDATE products SET category_id=? WHERE category_id=?", (target_id, source_id)
        )

    async def delete_product(self, product_id: int):
        await self._execute("DELETE FROM products WHERE id=?", (product_id,))

    async def add_to_cart(self, user_id: int, product_id: int):
        await self._execute(
            """INSERT INTO carts(user_id,product_id,quantity) VALUES(?,?,1)
               ON CONFLICT(user_id,product_id) DO UPDATE SET quantity=quantity+1""",
            (user_id, product_id),
        )

    async def cart(self, user_id: int):
        return await self._fetchall(
            "SELECT c.product_id,c.quantity,p.name,p.price FROM carts c JOIN products p ON p.id=c.product_id WHERE c.user_id=?",
            (user_id,),
        )

    async def remove_cart_item(self, user_id: int, product_id: int):
        await self._execute(
            "DELETE FROM carts WHERE user_id=? AND product_id=?", (user_id, product_id)
        )

    async def create_order(self, user_id: int, name: str, phone: str, address: str):
        items = await self.cart(user_id)
        if not items:
            return None
        total = sum(row["price"] * row["quantity"] for row in items)
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cursor = await db.execute(
                "INSERT INTO orders(user_id,customer_name,phone,address,total) VALUES(?,?,?,?,?)",
                (user_id, name, phone, address, total),
            )
            order_id = cursor.lastrowid
            await db.executemany(
                "INSERT INTO order_items(order_id,product_name,price,quantity) VALUES(?,?,?,?)",
                [(order_id, r["name"], r["price"], r["quantity"]) for r in items],
            )
            await db.execute("DELETE FROM carts WHERE user_id=?", (user_id,))
            await db.commit()
        return await self.order(order_id)

    async def order(self, order_id: int):
        order = await self._fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
        if not order:
            return None
        return order, await self._fetchall(
            "SELECT * FROM order_items WHERE order_id=?", (order_id,)
        )

    async def orders(self):
        return await self._fetchall("SELECT * FROM orders ORDER BY id DESC")

    async def set_order_status(self, order_id: int, status: str):
        await self._execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
