from pathlib import Path
import aiosqlite


class Database:
    def __init__(self, path: Path):
        self.path = path

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db:
            await db.executescript("""
            PRAGMA foreign_keys = ON;
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                price INTEGER NOT NULL CHECK(price >= 0),
                photo_id TEXT
            );
            CREATE TABLE IF NOT EXISTS carts (
                user_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
                quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0),
                PRIMARY KEY(user_id, product_id)
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                customer_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL,
                total INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'Yangi',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                product_name TEXT NOT NULL,
                price INTEGER NOT NULL,
                quantity INTEGER NOT NULL
            );
            """)
            await db.executemany("INSERT OR IGNORE INTO categories(name) VALUES(?)", [("Soatlar",), ("Zargarlik buyumlari",), ("Sumkalar",), ("Ko'zoynaklar",)])
            await db.commit()

    async def _fetchall(self, query, params=()):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(query, params) as cursor:
                return await cursor.fetchall()

    async def _fetchone(self, query, params=()):
        rows = await self._fetchall(query, params)
        return rows[0] if rows else None

    async def categories(self):
        return await self._fetchall("SELECT * FROM categories ORDER BY name")

    async def products_by_category(self, category_id: int):
        return await self._fetchall("SELECT * FROM products WHERE category_id=? ORDER BY id DESC", (category_id,))

    async def product(self, product_id: int):
        return await self._fetchone("SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?", (product_id,))

    async def add_product(self, category: str, name: str, description: str, price: int, photo_id: str | None):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("INSERT OR IGNORE INTO categories(name) VALUES(?)", (category.strip(),))
            row = await (await db.execute("SELECT id FROM categories WHERE name=?", (category.strip(),))).fetchone()
            await db.execute("INSERT INTO products(category_id,name,description,price,photo_id) VALUES(?,?,?,?,?)", (row[0], name, description, price, photo_id))
            await db.commit()

    async def update_product(self, product_id: int, field: str, value):
        allowed = {"name", "description", "price", "photo_id"}
        if field not in allowed:
            raise ValueError("Noto'g'ri ustun")
        async with aiosqlite.connect(self.path) as db:
            await db.execute(f"UPDATE products SET {field}=? WHERE id=?", (value, product_id))
            await db.commit()

    async def delete_product(self, product_id: int):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("DELETE FROM products WHERE id=?", (product_id,))
            await db.commit()

    async def add_to_cart(self, user_id: int, product_id: int):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("INSERT INTO carts(user_id,product_id,quantity) VALUES(?,?,1) ON CONFLICT(user_id,product_id) DO UPDATE SET quantity=quantity+1", (user_id, product_id))
            await db.commit()

    async def cart(self, user_id: int):
        return await self._fetchall("SELECT c.product_id,c.quantity,p.name,p.price FROM carts c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", (user_id,))

    async def remove_cart_item(self, user_id: int, product_id: int):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("DELETE FROM carts WHERE user_id=? AND product_id=?", (user_id, product_id))
            await db.commit()

    async def create_order(self, user_id: int, name: str, phone: str, address: str):
        items = await self.cart(user_id)
        if not items:
            return None
        total = sum(row["price"] * row["quantity"] for row in items)
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute("INSERT INTO orders(user_id,customer_name,phone,address,total) VALUES(?,?,?,?,?)", (user_id, name, phone, address, total))
            order_id = cursor.lastrowid
            await db.executemany("INSERT INTO order_items(order_id,product_name,price,quantity) VALUES(?,?,?,?)", [(order_id, r["name"], r["price"], r["quantity"]) for r in items])
            await db.execute("DELETE FROM carts WHERE user_id=?", (user_id,))
            await db.commit()
        return await self.order(order_id)

    async def order(self, order_id: int):
        order = await self._fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
        if order:
            order_items = await self._fetchall("SELECT * FROM order_items WHERE order_id=?", (order_id,))
            return order, order_items
        return None

    async def orders(self):
        return await self._fetchall("SELECT * FROM orders ORDER BY id DESC")

    async def set_order_status(self, order_id: int, status: str):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
            await db.commit()
