from aiogram.utils.keyboard import InlineKeyboardBuilder


def categories_keyboard(categories):
    builder = InlineKeyboardBuilder()
    for category in categories:
        builder.button(text=category["name"], callback_data=f"cat:{category['id']}")
    builder.adjust(2)
    return builder.as_markup()


def products_keyboard(products):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(text=f"{product['name']} — {product['price']:,} so'm", callback_data=f"product:{product['id']}")
    builder.button(text="⬅️ Kategoriyalar", callback_data="catalog")
    builder.adjust(1)
    return builder.as_markup()


def product_keyboard(product_id: int):
    builder = InlineKeyboardBuilder()
    builder.button(text="🛒 Savatga qo'shish", callback_data=f"addcart:{product_id}")
    builder.button(text="⬅️ Orqaga", callback_data="catalog")
    builder.adjust(1)
    return builder.as_markup()


def cart_keyboard(items):
    builder = InlineKeyboardBuilder()
    for item in items:
        builder.button(text=f"❌ {item['name']}", callback_data=f"remove:{item['product_id']}")
    builder.button(text="✅ Buyurtma berish", callback_data="checkout")
    builder.adjust(1)
    return builder.as_markup()


def admin_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Mahsulot qo'shish", callback_data="admin:add")
    builder.button(text="✏️ Mahsulotlar", callback_data="admin:products")
    builder.button(text="📦 Buyurtmalar", callback_data="admin:orders")
    builder.adjust(1)
    return builder.as_markup()


def admin_products_keyboard(products):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(text=f"{product['id']}. {product['name']}", callback_data=f"adminproduct:{product['id']}")
    builder.adjust(1)
    return builder.as_markup()


def admin_product_keyboard(product_id: int):
    builder = InlineKeyboardBuilder()
    for field, label in [("name", "Nom"), ("description", "Tavsif"), ("price", "Narx"), ("photo", "Rasm")]:
        builder.button(text=f"✏️ {label}", callback_data=f"edit:{product_id}:{field}")
    builder.button(text="🗑 O'chirish", callback_data=f"delete:{product_id}")
    builder.adjust(2)
    return builder.as_markup()


def order_keyboard(order_id: int):
    builder = InlineKeyboardBuilder()
    for status in ("Qabul qilindi", "Yetkazilmoqda", "Yakunlandi", "Bekor qilindi"):
        builder.button(text=status, callback_data=f"status:{order_id}:{status}")
    builder.adjust(2)
    return builder.as_markup()
