def calculate_discount(promo, subtotal: int) -> int:
    if not promo or subtotal < promo["min_order"]:
        return 0
    if promo["discount_type"] == "percent":
        return min(subtotal, subtotal * promo["discount_value"] // 100)
    return min(subtotal, promo["discount_value"])


def earned_bonus(total: int, percent: int = 2) -> int:
    return max(0, total * percent // 100)


def referral_bonus(total: int, percent: int = 3) -> int:
    return max(0, total * percent // 100)
