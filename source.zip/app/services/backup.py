import asyncio
import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path


def create_backup(database_path: Path, backup_dir: Path) -> Path | None:
    if not database_path.exists():
        return None
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"accessories-{datetime.now():%Y%m%d-%H%M%S}.db"
    source = sqlite3.connect(database_path)
    destination = sqlite3.connect(target)
    try:
        source.backup(destination)
    finally:
        destination.close()
        source.close()
    cutoff = datetime.now() - timedelta(days=14)
    for old in backup_dir.glob("accessories-*.db"):
        if datetime.fromtimestamp(old.stat().st_mtime) < cutoff:
            old.unlink(missing_ok=True)
    return target


async def backup_loop(database_path: Path, backup_dir: Path, interval_hours: int = 6):
    while True:
        try:
            target = await asyncio.to_thread(create_backup, database_path, backup_dir)
            if target:
                logging.info("Database backup yaratildi: %s", target)
        except Exception:
            logging.exception("Database backup yaratishda xato")
        await asyncio.sleep(interval_hours * 3600)
