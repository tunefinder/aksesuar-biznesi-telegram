ROLE_PERMISSIONS = {
    "super_admin": {"*"},
    "operator": {
        "orders",
        "payments",
        "customers",
        "promos",
        "delivery",
        "ads",
        "stats",
    },
    "warehouse": {"inventory", "exchange", "stats"},
    "courier": {"orders"},
}


def has_permission(role: str | None, permission: str) -> bool:
    permissions = ROLE_PERMISSIONS.get(role or "", set())
    return "*" in permissions or permission in permissions
