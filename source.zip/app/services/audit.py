import json

from app.database import Database


async def log_action(
    db: Database,
    admin_id: int,
    action: str,
    entity_type: str | None = None,
    entity_id=None,
    **details,
):
    await db.audit(
        admin_id,
        action,
        entity_type,
        entity_id,
        json.dumps(details, ensure_ascii=False, default=str),
    )
