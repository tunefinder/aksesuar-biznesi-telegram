import csv
from pathlib import Path

import aiosqlite


PRODUCT_COLUMNS = (
    "id",
    "category",
    "name",
    "description",
    "brand",
    "sku",
    "base_price",
    "variant_sku",
    "color",
    "phone_model",
    "variant_price",
    "stock",
    "active",
)


async def export_products_csv(database_path: Path, output_path: Path) -> Path:
    async with aiosqlite.connect(database_path) as db:
        db.row_factory = aiosqlite.Row
        rows = await (
            await db.execute(
                """SELECT p.id,c.name category,p.name,p.description,p.brand,p.sku,
                          p.price base_price,v.sku variant_sku,v.color,v.phone_model,
                          v.price variant_price,v.stock,p.is_active active
                   FROM products p JOIN categories c ON c.id=p.category_id
                   LEFT JOIN product_variants v ON v.product_id=p.id
                   ORDER BY p.id,v.id"""
            )
        ).fetchall()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=PRODUCT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row[column] for column in PRODUCT_COLUMNS})
    return output_path


async def import_products_csv(database_path: Path, input_path: Path) -> dict[str, int]:
    created_products = created_variants = skipped = 0
    with input_path.open("r", newline="", encoding="utf-8-sig") as file:
        rows = list(csv.DictReader(file))
    async with aiosqlite.connect(database_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        for row in rows:
            try:
                category_name = row["category"].strip()
                await db.execute(
                    "INSERT OR IGNORE INTO categories(name,sort_order) VALUES(?,9999)",
                    (category_name,),
                )
                category = await (
                    await db.execute("SELECT id FROM categories WHERE name=?", (category_name,))
                ).fetchone()
                product_id = int(row["id"]) if row.get("id") else None
                product = (
                    await (
                        await db.execute("SELECT id FROM products WHERE id=?", (product_id,))
                    ).fetchone()
                    if product_id
                    else None
                )
                if not product:
                    cursor = await db.execute(
                        """INSERT INTO products(category_id,name,description,brand,sku,price,is_active)
                           VALUES(?,?,?,?,?,?,?)""",
                        (
                            category[0],
                            row["name"].strip(),
                            row.get("description", "").strip(),
                            row.get("brand") or None,
                            row.get("sku") or None,
                            int(row.get("base_price") or 0),
                            int(row.get("active") or 1),
                        ),
                    )
                    product_id = cursor.lastrowid
                    created_products += 1
                if row.get("variant_price"):
                    await db.execute(
                        """INSERT INTO product_variants(
                           product_id,sku,color,phone_model,price,stock)
                           VALUES(?,?,?,?,?,?)""",
                        (
                            product_id,
                            row.get("variant_sku") or None,
                            row.get("color") or None,
                            row.get("phone_model") or None,
                            int(row["variant_price"]),
                            int(row.get("stock") or 0),
                        ),
                    )
                    created_variants += 1
            except (KeyError, ValueError, aiosqlite.IntegrityError):
                skipped += 1
        await db.commit()
    return {
        "products": created_products,
        "variants": created_variants,
        "skipped": skipped,
    }
