import json


def variant_label(variant) -> str:
    parts = [
        variant["color"],
        variant["phone_model"],
    ]
    try:
        attributes = json.loads(variant["attributes_json"] or "{}")
    except json.JSONDecodeError:
        attributes = {}
    parts.extend(f"{key}: {value}" for key, value in attributes.items())
    return " · ".join(str(part) for part in parts if part) or f"Variant #{variant['id']}"


def stock_label(stock: int) -> str:
    if stock <= 0:
        return "❌ Tugagan"
    if stock <= 5:
        return f"⚠️ {stock} dona qoldi"
    return f"✅ Omborda {stock} dona"
