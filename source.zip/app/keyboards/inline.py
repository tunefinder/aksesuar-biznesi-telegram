from aiogram.utils.keyboard import InlineKeyboardBuilder


def category_title(category):
    prefix = f"{category['emoji']} " if category["emoji"] else ""
    return f"{prefix}{category['name']}"


def categories_keyboard(categories, parent_id=None):
    builder = InlineKeyboardBuilder()
    for category in categories:
        builder.button(text=category_title(category), callback_data=f"cat:{category['id']}")
    if parent_id is not None:
        builder.button(text="⬅️ Orqaga", callback_data="catalog")
    builder.adjust(2)
    return builder.as_markup()


def products_keyboard(products, category_id, has_parent=False):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(
            text=f"{product['name']} — {product['price']:,} so'm",
            callback_data=f"product:{product['id']}",
        )
    builder.button(text="⬅️ Orqaga", callback_data=f"catback:{category_id}" if has_parent else "catalog")
    builder.adjust(1)
    return builder.as_markup()


def product_keyboard(product_id: int, category_id: int):
    builder = InlineKeyboardBuilder()
    builder.button(text="🛒 Savatga qo'shish", callback_data=f"addcart:{product_id}")
    builder.button(text="❤️ Sevimlilarga", callback_data=f"favorite:{product_id}")
    builder.button(text="⬅️ Orqaga", callback_data=f"cat:{category_id}")
    builder.adjust(1)
    return builder.as_markup()


def variants_keyboard(variants, product_id):
    from app.services.catalog import stock_label, variant_label

    builder = InlineKeyboardBuilder()
    for variant in variants:
        builder.button(
            text=f"{variant_label(variant)} · {variant['price']:,} · {stock_label(variant['stock'])}",
            callback_data=f"variant:{variant['id']}",
        )
    builder.button(text="❤️ Sevimlilarga", callback_data=f"favorite:{product_id}")
    builder.adjust(1)
    return builder.as_markup()


def search_results_keyboard(products, show_filters=True):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(
            text=f"{product['name']} · {product['display_price']:,} so‘m",
            callback_data=f"product:{product['id']}",
        )
    if show_filters:
        builder.button(text="📦 Faqat omborda bor", callback_data="searchfilter:stock")
        builder.button(text="💰 0–100 ming", callback_data="searchfilter:0:100000")
        builder.button(text="💰 100–300 ming", callback_data="searchfilter:100000:300000")
        builder.button(text="💎 300 mingdan yuqori", callback_data="searchfilter:300000:0")
    builder.adjust(1)
    return builder.as_markup()


def favorites_keyboard(products):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(text=product["name"], callback_data=f"product:{product['id']}")
        builder.button(text="💔 Olib tashlash", callback_data=f"favorite:{product['id']}")
    builder.adjust(2)
    return builder.as_markup()


def delivery_zones_keyboard(zones):
    builder = InlineKeyboardBuilder()
    for zone in zones:
        builder.button(
            text=f"{zone['name']} · {zone['price']:,} so‘m",
            callback_data=f"checkoutzone:{zone['id']}",
        )
    builder.adjust(1)
    return builder.as_markup()


def promo_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="⏭ Promokodsiz davom etish", callback_data="checkoutpromo:skip")
    return builder.as_markup()


def payment_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="💵 Naqd", callback_data="checkoutpay:cash")
    builder.button(text="💳 Karta", callback_data="checkoutpay:card")
    builder.button(text="🧾 Chek yuborish", callback_data="checkoutpay:receipt")
    builder.adjust(1)
    return builder.as_markup()


def cart_keyboard(items):
    builder = InlineKeyboardBuilder()
    for item in items:
        builder.button(
            text=f"❌ {item['name']}",
            callback_data=f"remove:{item['product_id']}:{item['variant_id'] or 0}",
        )
    builder.button(text="✅ Buyurtma berish", callback_data="checkout")
    builder.adjust(1)
    return builder.as_markup()


def admin_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="🗂 Kategoriyalar", callback_data="admin:categories")
    builder.button(text="➕ Mahsulot qo'shish", callback_data="admin:add")
    builder.button(text="✏️ Mahsulotlar", callback_data="admin:products")
    builder.button(text="📦 Buyurtmalar", callback_data="admin:orders")
    builder.button(text="🏷 Variant va ombor", callback_data="admin:inventory")
    builder.button(text="🎟 Promokodlar", callback_data="admin:promos")
    builder.button(text="🚚 Yetkazib berish", callback_data="admin:delivery")
    builder.button(text="👥 Xodimlar va rollar", callback_data="admin:staff")
    builder.button(text="👤 Mijozlar", callback_data="admin:customers")
    builder.button(text="💳 To‘lovlar", callback_data="admin:payments")
    builder.button(text="📊 Statistika", callback_data="admin:stats")
    builder.button(text="📥 Import / 📤 Eksport", callback_data="admin:exchange")
    builder.button(text="📣 Reklama", callback_data="admin:ads")
    builder.adjust(1)
    return builder.as_markup()


def admin_categories_keyboard(categories):
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Yangi kategoriya", callback_data="catadmin:new")
    for category in categories:
        indent = "↳ " if category["parent_id"] else ""
        status = "✅" if category["is_active"] else "🙈"
        builder.button(
            text=f"{status} {indent}{category_title(category)} ({category['product_count']})",
            callback_data=f"catadmin:{category['id']}",
        )
    builder.button(text="⬅️ Admin panel", callback_data="admin:home")
    builder.adjust(1)
    return builder.as_markup()


def admin_category_keyboard(category_id, is_active):
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Nom", callback_data=f"catedit:{category_id}:name")
    builder.button(text="📝 Tavsif", callback_data=f"catedit:{category_id}:description")
    builder.button(text="😀 Emoji", callback_data=f"catedit:{category_id}:emoji")
    builder.button(text="🖼 Rasm", callback_data=f"catedit:{category_id}:photo")
    builder.button(
        text="🙈 Yashirish" if is_active else "✅ Aktiv qilish",
        callback_data=f"cattoggle:{category_id}",
    )
    builder.button(text="⬆️ Yuqoriga", callback_data=f"catmove:{category_id}:-1")
    builder.button(text="⬇️ Pastga", callback_data=f"catmove:{category_id}:1")
    builder.button(text="↳ Ichki kategoriya", callback_data=f"catsub:{category_id}")
    builder.button(text="📦 Mahsulotlarni ko'chirish", callback_data=f"catproducts:{category_id}")
    builder.button(text="🗑 O'chirish", callback_data=f"catdelete:{category_id}")
    builder.button(text="⬅️ Kategoriyalar", callback_data="admin:categories")
    builder.adjust(2, 2, 1, 2, 1, 1, 1)
    return builder.as_markup()


def category_select_keyboard(categories, prefix, exclude_id=None, allow_root=False):
    builder = InlineKeyboardBuilder()
    if allow_root:
        builder.button(text="🏠 Asosiy kategoriya", callback_data=f"{prefix}:0")
    for category in categories:
        if category["id"] == exclude_id:
            continue
        builder.button(text=category_title(category), callback_data=f"{prefix}:{category['id']}")
    builder.adjust(1)
    return builder.as_markup()


def category_delete_keyboard(category_id, has_products):
    builder = InlineKeyboardBuilder()
    if has_products:
        builder.button(text="📦 Boshqa kategoriyaga ko'chirish", callback_data=f"catdelmove:{category_id}")
        builder.button(text="🗑 Mahsulotlar bilan o'chirish", callback_data=f"catdelall:{category_id}")
    else:
        builder.button(text="✅ O'chirishni tasdiqlash", callback_data=f"catdelconfirm:{category_id}")
    builder.button(text="❌ Bekor qilish", callback_data=f"catadmin:{category_id}")
    builder.adjust(1)
    return builder.as_markup()


def admin_products_keyboard(products):
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(
            text=f"{product['id']}. {product['name']} · {product['category_name']}",
            callback_data=f"adminproduct:{product['id']}",
        )
    builder.adjust(1)
    return builder.as_markup()


def admin_product_keyboard(product_id: int):
    builder = InlineKeyboardBuilder()
    for field, label in [
        ("name", "Nom"),
        ("description", "Tavsif"),
        ("price", "Narx"),
        ("photo", "Rasm"),
    ]:
        builder.button(text=f"✏️ {label}", callback_data=f"edit:{product_id}:{field}")
    builder.button(text="🗂 Kategoriyani almashtirish", callback_data=f"prodcat:{product_id}")
    builder.button(text="🏷 Variantlar", callback_data=f"variants:{product_id}")
    builder.button(text="🗑 O'chirish", callback_data=f"delete:{product_id}")
    builder.adjust(2, 2, 1, 1, 1)
    return builder.as_markup()


def order_keyboard(order_id: int):
    builder = InlineKeyboardBuilder()
    for status in ("Qabul qilindi", "Yetkazilmoqda", "Yakunlandi", "Bekor qilindi"):
        builder.button(text=status, callback_data=f"status:{order_id}:{status}")
    builder.adjust(2)
    return builder.as_markup()


def variants_admin_keyboard(variants, product_id):
    from app.services.catalog import variant_label

    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Variant qo‘shish", callback_data=f"variantnew:{product_id}")
    for variant in variants:
        builder.button(
            text=f"{variant_label(variant)} · {variant['price']:,} · {variant['stock']} dona",
            callback_data=f"variantadmin:{variant['id']}",
        )
    builder.adjust(1)
    return builder.as_markup()


def variant_admin_keyboard(variant_id):
    builder = InlineKeyboardBuilder()
    for field, label in [
        ("price", "💳 Narx"),
        ("stock", "📦 Qoldiq"),
        ("color", "🎨 Rang"),
        ("phone_model", "📱 Model"),
        ("sku", "🏷 SKU"),
    ]:
        builder.button(text=label, callback_data=f"variantedit:{variant_id}:{field}")
    builder.button(text="🙈 Aktiv/yashirin", callback_data=f"varianttoggle:{variant_id}")
    builder.adjust(2)
    return builder.as_markup()


def professional_admin_section(items):
    builder = InlineKeyboardBuilder()
    for text, callback_data in items:
        builder.button(text=text, callback_data=callback_data)
    builder.button(text="⬅️ Admin panel", callback_data="admin:home")
    builder.adjust(1)
    return builder.as_markup()
