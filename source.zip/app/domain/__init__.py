"""Business-domain constants and validation helpers."""
