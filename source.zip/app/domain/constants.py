ROLES = ("super_admin", "operator", "warehouse", "courier")
PAYMENT_METHODS = ("cash", "card", "receipt")
PAYMENT_STATUSES = ("pending", "paid", "rejected", "refunded")
ORDER_STATUSES = (
    "Yangi",
    "Qabul qilindi",
    "Tayyorlanmoqda",
    "Kuryerga berildi",
    "Yetkazilmoqda",
    "Yakunlandi",
    "Bekor qilindi",
)

ROLE_LABELS = {
    "super_admin": "Super admin",
    "operator": "Operator",
    "warehouse": "Omborchi",
    "courier": "Kuryer",
}

PAYMENT_LABELS = {
    "cash": "Naqd",
    "card": "Karta",
    "receipt": "Chek yuborish",
}
