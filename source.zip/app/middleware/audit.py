import json
from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, TelegramObject


class AdminAuditMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        result = await handler(event, data)
        if isinstance(event, CallbackQuery):
            admin_ids = data.get("admin_ids", set())
            db = data.get("db")
            if db and event.from_user.id in admin_ids:
                try:
                    await db.audit(
                        event.from_user.id,
                        "callback",
                        "telegram_callback",
                        event.data,
                        json.dumps(
                            {"chat_id": event.message.chat.id if event.message else None}
                        ),
                    )
                except Exception:
                    pass
        return result
