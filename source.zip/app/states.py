from aiogram.fsm.state import State, StatesGroup


class Checkout(StatesGroup):
    name = State()
    phone = State()
    address = State()
    delivery = State()
    promo = State()
    payment = State()
    receipt = State()


class ProductForm(StatesGroup):
    name = State()
    description = State()
    price = State()
    photo = State()
    category = State()


class ProductEdit(StatesGroup):
    value = State()


class CategoryForm(StatesGroup):
    name = State()
    description = State()
    media = State()
    parent = State()


class CategoryEdit(StatesGroup):
    value = State()


class SearchForm(StatesGroup):
    query = State()


class VariantForm(StatesGroup):
    color = State()
    phone_model = State()
    price = State()
    stock = State()
    sku = State()


class PromoForm(StatesGroup):
    code = State()
    discount_type = State()
    value = State()
    min_order = State()


class DeliveryZoneForm(StatesGroup):
    name = State()
    price = State()


class RoleForm(StatesGroup):
    user_id = State()
    role = State()


class ProductImport(StatesGroup):
    file = State()


class VariantEdit(StatesGroup):
    value = State()


class AdvertisementForm(StatesGroup):
    title = State()
    text = State()
    photo = State()
