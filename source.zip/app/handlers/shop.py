from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.database import Database
from app.keyboards.inline import (
    favorites_keyboard,
    search_results_keyboard,
)
from app.services.orders import money
from app.states import SearchForm

router = Router()


@router.message(F.text == "🔎 Qidirish")
async def search_start(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(SearchForm.query)
    await message.answer(
        "Mahsulot nomi, telefon modeli, rang yoki brendni kiriting:"
    )


@router.message(SearchForm.query)
async def search_result(message: Message, state: FSMContext, db: Database):
    products = await db.search_products(message.text or "")
    await state.update_data(search_query=message.text or "")
    await state.set_state(None)
    if not products:
        return await message.answer("Hech narsa topilmadi.")
    await message.answer(
        f"🔎 <b>{len(products)} ta natija topildi:</b>",
        reply_markup=search_results_keyboard(products),
    )


@router.callback_query(F.data.startswith("searchfilter:"))
async def search_filter(
    callback: CallbackQuery, state: FSMContext, db: Database
):
    data = await state.get_data()
    query = data.get("search_query", "")
    parts = callback.data.split(":")
    if parts[1] == "stock":
        products = await db.search_products(query, in_stock=True)
    else:
        minimum = int(parts[1])
        maximum = int(parts[2]) or None
        products = await db.search_products(
            query, min_price=minimum, max_price=maximum
        )
    if not products:
        return await callback.answer("Bu filtr bo‘yicha mahsulot topilmadi.", show_alert=True)
    await callback.message.edit_reply_markup(
        reply_markup=search_results_keyboard(products, show_filters=False)
    )
    await callback.answer(f"{len(products)} ta mahsulot")


@router.callback_query(F.data.startswith("favorite:"))
async def favorite_toggle(callback: CallbackQuery, db: Database):
    product_id = int(callback.data.split(":")[1])
    added = await db.toggle_favorite(callback.from_user.id, product_id)
    await callback.answer(
        "Sevimlilarga qo‘shildi ❤️" if added else "Sevimlilardan olib tashlandi"
    )


@router.message(F.text == "❤️ Sevimlilar")
async def favorites(message: Message, state: FSMContext, db: Database):
    await state.clear()
    products = await db.favorites(message.from_user.id)
    if not products:
        return await message.answer("Sevimlilar ro‘yxati bo‘sh.")
    await message.answer(
        "<b>❤️ Sevimli mahsulotlaringiz</b>",
        reply_markup=favorites_keyboard(products),
    )


@router.message(F.text == "📦 Buyurtmalarim")
async def order_history(message: Message, state: FSMContext, db: Database):
    await state.clear()
    orders = await db.user_orders(message.from_user.id)
    if not orders:
        return await message.answer("Sizda hali buyurtmalar yo‘q.")
    lines = ["<b>📦 Buyurtmalar tarixi</b>", ""]
    for order in orders:
        number = order["order_number"] or f"#{order['id']}"
        lines.append(
            f"<b>{number}</b> · {money(order['total'])}\n"
            f"Holat: {order['status']} · To‘lov: {order['payment_status']}"
        )
    await message.answer("\n\n".join(lines))


@router.message(F.text == "🎁 Bonuslarim")
async def bonuses(message: Message, state: FSMContext, db: Database):
    await state.clear()
    user = await db.user(message.from_user.id)
    if not user:
        await db.register_user(
            message.from_user.id, message.from_user.full_name, message.from_user.username
        )
        user = await db.user(message.from_user.id)
    referral_link = f"https://t.me/aksesuar_biznesi_uz_bot?start={user['referral_code']}"
    await message.answer(
        f"<b>🎁 Bonus balansingiz: {money(user['bonus_balance'])}</b>\n\n"
        f"Do‘stlaringizni taklif qiling:\n<code>{referral_link}</code>"
    )
