import json
from pathlib import Path

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message

from app.database import Database
from app.domain.constants import ROLE_LABELS, ROLES
from app.keyboards.inline import (
    professional_admin_section,
    variant_admin_keyboard,
    variants_admin_keyboard,
)
from app.services.audit import log_action
from app.services.catalog import stock_label, variant_label
from app.services.reporting import export_products_csv, import_products_csv
from app.services.permissions import has_permission
from app.states import (
    DeliveryZoneForm,
    ProductImport,
    PromoForm,
    RoleForm,
    VariantEdit,
    VariantForm,
    AdvertisementForm,
)

router = Router()
STAFF_ROLES: dict[int, str] = {}


def configure_staff(rows):
    STAFF_ROLES.clear()
    STAFF_ROLES.update({row["user_id"]: row["role"] for row in rows})


def allowed(event, admin_ids, permission="*"):
    if event.from_user.id in admin_ids:
        return True
    return has_permission(STAFF_ROLES.get(event.from_user.id), permission)


@router.message(Command("admin"))
async def staff_panel(message: Message, db: Database, admin_ids: set[int]):
    role = STAFF_ROLES.get(message.from_user.id)
    if message.from_user.id not in admin_ids and not role:
        return await message.answer("Sizda admin paneliga ruxsat yo‘q.")
    if message.from_user.id in admin_ids or role == "super_admin":
        items = [
            ("🏷 Variant va ombor", "admin:inventory"),
            ("🎟 Promokodlar", "admin:promos"),
            ("🚚 Yetkazib berish", "admin:delivery"),
            ("👤 Mijozlar", "admin:customers"),
            ("💳 To‘lovlar", "admin:payments"),
            ("📊 Statistika", "admin:stats"),
            ("📥 Import / 📤 Eksport", "admin:exchange"),
            ("📣 Reklama", "admin:ads"),
        ]
    else:
        mapping = {
            "operator": [
                ("📦 Buyurtmalar", "stafforders"),
                ("💳 To‘lovlar", "admin:payments"),
                ("👤 Mijozlar", "admin:customers"),
                ("🎟 Promokodlar", "admin:promos"),
                ("🚚 Yetkazib berish", "admin:delivery"),
                ("📣 Reklama", "admin:ads"),
                ("📊 Statistika", "admin:stats"),
            ],
            "warehouse": [
                ("🏷 Variant va ombor", "admin:inventory"),
                ("📥 Import / 📤 Eksport", "admin:exchange"),
                ("📊 Statistika", "admin:stats"),
            ],
            "courier": [("🚚 Mening buyurtmalarim", "stafforders")],
        }
        items = mapping.get(role, [])
    await message.answer(
        f"<b>⚙️ Xodim paneli</b>\nRol: {ROLE_LABELS.get(role, 'Super admin')}",
        reply_markup=professional_admin_section(items),
    )


@router.callback_query(F.data == "stafforders")
async def staff_orders(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "orders"):
        return
    rows = await db._fetchall(
        """SELECT * FROM orders
           WHERE status NOT IN ('Yakunlandi','Bekor qilindi')
           ORDER BY id DESC LIMIT 30"""
    )
    items = [
        (
            f"{row['order_number']} · {row['status']}",
            f"stafforder:{row['id']}",
        )
        for row in rows
    ]
    await callback.message.answer(
        "<b>📦 Faol buyurtmalar</b>",
        reply_markup=professional_admin_section(items),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("stafforder:"))
async def staff_order(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "orders"):
        return
    order_id = int(callback.data.split(":")[1])
    result = await db.order(order_id)
    if not result:
        return await callback.answer("Buyurtma topilmadi.", show_alert=True)
    order, items = result
    lines = [
        f"<b>{order['order_number']}</b>",
        f"Mijoz: {order['customer_name']}",
        f"Telefon: {order['phone']}",
        f"Manzil: {order['address']}",
        f"Holat: {order['status']}",
    ]
    buttons = [
        ("Qabul qilindi", f"staffstatus:{order_id}:Qabul qilindi"),
        ("Yetkazilmoqda", f"staffstatus:{order_id}:Yetkazilmoqda"),
        ("Yakunlandi", f"staffstatus:{order_id}:Yakunlandi"),
    ]
    await callback.message.answer(
        "\n".join(lines), reply_markup=professional_admin_section(buttons)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("staffstatus:"))
async def staff_order_status(
    callback: CallbackQuery, db: Database, bot, admin_ids: set[int]
):
    if not allowed(callback, admin_ids, "orders"):
        return
    _, order_id, status = callback.data.split(":", 2)
    await db.set_order_status(int(order_id), status)
    result = await db.order(int(order_id))
    if result:
        order, _ = result
        await bot.send_message(
            order["user_id"],
            f"📦 <b>{order['order_number']}</b> holati: <b>{status}</b>",
        )
    await log_action(
        db, callback.from_user.id, "staff_order_status", "order", order_id, status=status
    )
    await callback.answer("Holat yangilandi")


@router.callback_query(F.data == "admin:inventory")
async def inventory(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "inventory"):
        return
    products = await db.products()
    await callback.message.answer(
        "<b>🏷 Variant va ombor boshqaruvi</b>\nMahsulotni tanlang:",
        reply_markup=professional_admin_section(
            [(product["name"], f"variants:{product['id']}") for product in products]
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("variants:"))
async def variants_list(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "inventory"):
        return
    product_id = int(callback.data.split(":")[1])
    product = await db.product(product_id)
    variants = await db.variants(product_id, active_only=False)
    await callback.message.answer(
        f"<b>{product['name']} — variantlar</b>",
        reply_markup=variants_admin_keyboard(variants, product_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("variantnew:"))
async def variant_new(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "inventory"):
        return
    await state.clear()
    await state.update_data(product_id=int(callback.data.split(":")[1]))
    await state.set_state(VariantForm.color)
    await callback.message.answer("Variant rangini kiriting yoki /skip:")
    await callback.answer()


@router.message(VariantForm.color)
async def variant_color(message: Message, state: FSMContext):
    await state.update_data(color=None if message.text == "/skip" else message.text.strip())
    await state.set_state(VariantForm.phone_model)
    await message.answer("Telefon modelini kiriting yoki /skip:")


@router.message(VariantForm.phone_model)
async def variant_model(message: Message, state: FSMContext):
    await state.update_data(
        phone_model=None if message.text == "/skip" else message.text.strip()
    )
    await state.set_state(VariantForm.price)
    await message.answer("Variant narxini kiriting:")


@router.message(VariantForm.price)
async def variant_price(message: Message, state: FSMContext):
    try:
        value = int(message.text.replace(" ", ""))
    except (ValueError, AttributeError):
        return await message.answer("Narx raqam bo‘lishi kerak.")
    await state.update_data(price=value)
    await state.set_state(VariantForm.stock)
    await message.answer("Ombor qoldig‘ini kiriting:")


@router.message(VariantForm.stock)
async def variant_stock(message: Message, state: FSMContext):
    try:
        value = int(message.text)
        if value < 0:
            raise ValueError
    except (ValueError, TypeError):
        return await message.answer("Qoldiq 0 yoki musbat raqam bo‘lishi kerak.")
    await state.update_data(stock=value)
    await state.set_state(VariantForm.sku)
    await message.answer("SKU kiriting yoki /skip:")


@router.message(VariantForm.sku)
async def variant_sku(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    variant_id = await db.add_variant(
        data["product_id"],
        data["price"],
        data["stock"],
        data["color"],
        data["phone_model"],
        None if message.text == "/skip" else message.text.strip(),
    )
    await log_action(
        db, message.from_user.id, "variant_created", "variant", variant_id
    )
    await state.clear()
    await message.answer("✅ Variant yaratildi.")


@router.callback_query(F.data.startswith("variantadmin:"))
async def variant_manage(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "inventory"):
        return
    variant = await db.variant(int(callback.data.split(":")[1]))
    await callback.message.answer(
        f"<b>{variant_label(variant)}</b>\n"
        f"Narx: {variant['price']:,} so‘m\n{stock_label(variant['stock'])}",
        reply_markup=variant_admin_keyboard(variant["id"]),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("varianttoggle:"))
async def variant_toggle(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "inventory"):
        return
    variant = await db.variant(int(callback.data.split(":")[1]))
    await db.update_variant(variant["id"], "is_active", 0 if variant["is_active"] else 1)
    await log_action(
        db, callback.from_user.id, "variant_toggled", "variant", variant["id"]
    )
    await callback.answer("Variant holati yangilandi")


@router.callback_query(F.data.startswith("variantedit:"))
async def variant_edit_start(
    callback: CallbackQuery, state: FSMContext, admin_ids: set[int]
):
    if not allowed(callback, admin_ids, "inventory"):
        return
    _, variant_id, field = callback.data.split(":")
    await state.update_data(variant_id=int(variant_id), variant_field=field)
    await state.set_state(VariantEdit.value)
    await callback.message.answer("Yangi qiymatni kiriting:")
    await callback.answer()


@router.message(VariantEdit.value)
async def variant_edit_save(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    field = data["variant_field"]
    value = message.text.strip()
    if field in {"price", "stock"}:
        try:
            value = int(value.replace(" ", ""))
            if value < 0:
                raise ValueError
        except ValueError:
            return await message.answer("0 yoki musbat raqam kiriting.")
    await db.update_variant(data["variant_id"], field, value)
    await log_action(
        db,
        message.from_user.id,
        "variant_updated",
        "variant",
        data["variant_id"],
        field=field,
    )
    await state.clear()
    await message.answer("✅ Variant yangilandi.")


@router.callback_query(F.data == "admin:promos")
async def promos(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "promos"):
        return
    promos = await db._fetchall("SELECT * FROM promocodes ORDER BY id DESC")
    text = ["<b>🎟 Promokodlar</b>"]
    text += [
        f"{row['code']} · {row['discount_value']}{'%' if row['discount_type']=='percent' else ' so‘m'}"
        for row in promos
    ]
    await callback.message.answer(
        "\n".join(text),
        reply_markup=professional_admin_section(
            [("➕ Promokod yaratish", "promonew")]
        ),
    )
    await callback.answer()


@router.callback_query(F.data == "promonew")
async def promo_new(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "promos"):
        return
    await state.clear()
    await state.set_state(PromoForm.code)
    await callback.message.answer("Promokod nomini kiriting:")
    await callback.answer()


@router.message(PromoForm.code)
async def promo_code(message: Message, state: FSMContext):
    await state.update_data(code=message.text.strip())
    await state.set_state(PromoForm.discount_type)
    await message.answer("Turini kiriting: percent yoki fixed")


@router.message(PromoForm.discount_type)
async def promo_type(message: Message, state: FSMContext):
    value = message.text.strip().lower()
    if value not in {"percent", "fixed"}:
        return await message.answer("Faqat percent yoki fixed kiriting.")
    await state.update_data(discount_type=value)
    await state.set_state(PromoForm.value)
    await message.answer("Chegirma qiymatini kiriting:")


@router.message(PromoForm.value)
async def promo_value(message: Message, state: FSMContext):
    try:
        value = int(message.text)
    except (ValueError, TypeError):
        return await message.answer("Raqam kiriting.")
    await state.update_data(value=value)
    await state.set_state(PromoForm.min_order)
    await message.answer("Minimal buyurtma summasini kiriting (0 mumkin):")


@router.message(PromoForm.min_order)
async def promo_min_order(message: Message, state: FSMContext, db: Database):
    try:
        minimum = int(message.text)
    except (ValueError, TypeError):
        return await message.answer("Raqam kiriting.")
    data = await state.get_data()
    promo_id = await db.add_promo(
        data["code"], data["discount_type"], data["value"], minimum
    )
    await log_action(db, message.from_user.id, "promo_created", "promo", promo_id)
    await state.clear()
    await message.answer("✅ Promokod yaratildi.")


@router.callback_query(F.data == "admin:delivery")
async def delivery(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "delivery"):
        return
    zones = await db.delivery_zones(active_only=False)
    text = ["<b>🚚 Yetkazib berish hududlari</b>"]
    text += [f"{z['name']} · {z['price']:,} so‘m" for z in zones]
    await callback.message.answer(
        "\n".join(text),
        reply_markup=professional_admin_section(
            [("➕ Hudud qo‘shish", "deliverynew")]
        ),
    )
    await callback.answer()


@router.callback_query(F.data == "deliverynew")
async def delivery_new(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "delivery"):
        return
    await state.clear()
    await state.set_state(DeliveryZoneForm.name)
    await callback.message.answer("Hudud nomini kiriting:")
    await callback.answer()


@router.message(DeliveryZoneForm.name)
async def delivery_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(DeliveryZoneForm.price)
    await message.answer("Yetkazish narxini kiriting:")


@router.message(DeliveryZoneForm.price)
async def delivery_price(message: Message, state: FSMContext, db: Database):
    try:
        price = int(message.text.replace(" ", ""))
    except (ValueError, AttributeError):
        return await message.answer("Narx raqam bo‘lishi kerak.")
    data = await state.get_data()
    zone_id = await db.add_delivery_zone(data["name"], price)
    await log_action(db, message.from_user.id, "delivery_zone_created", "zone", zone_id)
    await state.clear()
    await message.answer("✅ Yetkazib berish hududi qo‘shildi.")


@router.callback_query(F.data == "admin:stats")
async def stats(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "stats"):
        return
    data = await db.statistics()
    top = "\n".join(
        f"• {row['product_name']}: {row['quantity']} dona"
        for row in data["top_products"]
    ) or "Ma’lumot yo‘q"
    await callback.message.answer(
        "<b>📊 Sotuv statistikasi</b>\n\n"
        f"Buyurtmalar: {data['orders']['count']}\n"
        f"Daromad: {data['orders']['revenue']:,} so‘m\n"
        f"O‘rtacha chek: {data['orders']['average']:,.0f} so‘m\n"
        f"Mijozlar: {data['customers']['count']}\n"
        f"Mahsulotlar: {data['products']['count']}\n"
        f"Ombor: {data['stock']['units']} dona\n\n"
        f"<b>Top mahsulotlar</b>\n{top}"
    )
    await callback.answer()


@router.callback_query(F.data == "admin:exchange")
async def exchange(callback: CallbackQuery, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "exchange"):
        return
    await callback.message.answer(
        "<b>📥 Import / 📤 Eksport</b>",
        reply_markup=professional_admin_section(
            [
                ("📤 CSV eksport", "exportcsv"),
                ("📥 CSV import", "importcsv"),
            ]
        ),
    )
    await callback.answer()


@router.callback_query(F.data == "exportcsv")
async def export_csv(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "exchange"):
        return
    path = await export_products_csv(db.path, Path("data/exports/products.csv"))
    await callback.message.answer_document(
        FSInputFile(path), caption="Mahsulotlar va variantlar CSV eksporti"
    )
    await log_action(db, callback.from_user.id, "products_exported", "product")
    await callback.answer()


@router.callback_query(F.data == "importcsv")
async def import_csv_start(
    callback: CallbackQuery, state: FSMContext, admin_ids: set[int]
):
    if not allowed(callback, admin_ids, "exchange"):
        return
    await state.set_state(ProductImport.file)
    await callback.message.answer("CSV faylini yuboring:")
    await callback.answer()


@router.message(ProductImport.file)
async def import_csv_file(message: Message, state: FSMContext, db: Database, bot):
    if not message.document or not message.document.file_name.lower().endswith(".csv"):
        return await message.answer("Faqat .csv fayl yuboring.")
    path = Path("data/imports") / f"{message.from_user.id}-products.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    await bot.download(message.document, destination=path)
    result = await import_products_csv(db.path, path)
    await log_action(db, message.from_user.id, "products_imported", "product", **result)
    await state.clear()
    await message.answer(
        f"✅ Import tugadi.\nMahsulotlar: {result['products']}\n"
        f"Variantlar: {result['variants']}\nO‘tkazib yuborildi: {result['skipped']}"
    )


@router.callback_query(F.data == "admin:staff")
async def staff(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids):
        return
    rows = await db.staff()
    text = ["<b>👥 Xodimlar</b>"]
    text += [
        f"{row['user_id']} · {ROLE_LABELS.get(row['role'], row['role'])}" for row in rows
    ]
    await callback.message.answer(
        "\n".join(text),
        reply_markup=professional_admin_section(
            [("➕ Rol berish", "staffnew")]
        ),
    )
    await callback.answer()


@router.callback_query(F.data == "staffnew")
async def staff_new(callback: CallbackQuery, state: FSMContext, admin_ids: set[int]):
    if not allowed(callback, admin_ids):
        return
    await state.set_state(RoleForm.user_id)
    await callback.message.answer("Xodimning Telegram ID raqamini kiriting:")
    await callback.answer()


@router.message(RoleForm.user_id)
async def staff_user_id(message: Message, state: FSMContext):
    try:
        user_id = int(message.text)
    except (ValueError, TypeError):
        return await message.answer("Telegram ID raqam bo‘lishi kerak.")
    await state.update_data(user_id=user_id)
    await state.set_state(RoleForm.role)
    await message.answer("Rolni kiriting: super_admin, operator, warehouse yoki courier")


@router.message(RoleForm.role)
async def staff_role(message: Message, state: FSMContext, db: Database):
    role = message.text.strip()
    if role not in ROLES:
        return await message.answer("Noto‘g‘ri rol.")
    data = await state.get_data()
    await db.set_role(data["user_id"], role)
    await log_action(
        db, message.from_user.id, "staff_role_assigned", "user", data["user_id"], role=role
    )
    await state.clear()
    await message.answer("✅ Xodim roli saqlandi.")


@router.callback_query(F.data == "admin:customers")
async def customers(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "customers"):
        return
    rows = await db._fetchall(
        """SELECT u.*,
                  (SELECT COUNT(*) FROM orders o WHERE o.user_id=u.telegram_id) orders_count,
                  (SELECT COALESCE(SUM(total),0) FROM orders o WHERE o.user_id=u.telegram_id
                   AND o.status!='Bekor qilindi') spent
           FROM users u ORDER BY spent DESC LIMIT 50"""
    )
    text = ["<b>👤 Mijozlar</b>"]
    text += [
        f"{row['full_name']} · {row['orders_count']} buyurtma · {row['spent']:,} so‘m"
        for row in rows
    ]
    await callback.message.answer("\n".join(text))
    await callback.answer()


@router.callback_query(F.data == "admin:payments")
async def payments(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "payments"):
        return
    rows = await db._fetchall(
        """SELECT p.*,o.order_number,o.user_id FROM payments p
           JOIN orders o ON o.id=p.order_id ORDER BY p.id DESC LIMIT 50"""
    )
    items = []
    for row in rows:
        items.append(
            (
                f"{row['order_number']} · {row['amount']:,} · {row['status']}",
                f"payment:{row['id']}",
            )
        )
    await callback.message.answer(
        "<b>💳 To‘lovlar</b>",
        reply_markup=professional_admin_section(items),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("payment:"))
async def payment_manage(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "payments"):
        return
    payment_id = int(callback.data.split(":")[1])
    await callback.message.answer(
        "To‘lov holatini tanlang:",
        reply_markup=professional_admin_section(
            [
                ("✅ Tasdiqlash", f"paymentstatus:{payment_id}:paid"),
                ("❌ Rad etish", f"paymentstatus:{payment_id}:rejected"),
            ]
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("paymentstatus:"))
async def payment_status(
    callback: CallbackQuery, db: Database, bot, admin_ids: set[int]
):
    if not allowed(callback, admin_ids, "payments"):
        return
    _, payment_id, status = callback.data.split(":")
    payment = await db._fetchone(
        """SELECT p.*,o.user_id,o.order_number FROM payments p
           JOIN orders o ON o.id=p.order_id WHERE p.id=?""",
        (int(payment_id),),
    )
    await db._execute(
        """UPDATE payments SET status=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP
           WHERE id=?""",
        (status, callback.from_user.id, int(payment_id)),
    )
    await db._execute(
        "UPDATE orders SET payment_status=? WHERE id=?", (status, payment["order_id"])
    )
    await bot.send_message(
        payment["user_id"],
        f"💳 {payment['order_number']} buyurtma to‘lovi: <b>{status}</b>",
    )
    await log_action(
        db, callback.from_user.id, "payment_reviewed", "payment", payment_id, status=status
    )
    await callback.answer("To‘lov holati yangilandi")


@router.callback_query(F.data == "admin:ads")
async def advertisements(callback: CallbackQuery, db: Database, admin_ids: set[int]):
    if not allowed(callback, admin_ids, "ads"):
        return
    rows = await db._fetchall("SELECT * FROM advertisements ORDER BY id DESC LIMIT 20")
    text = ["<b>📣 Reklamalar</b>"]
    text += [f"{row['title']} · {'aktiv' if row['is_active'] else 'yopiq'}" for row in rows]
    await callback.message.answer(
        "\n".join(text),
        reply_markup=professional_admin_section(
            [("➕ Reklama tayyorlash", "adnew")]
        ),
    )
    await callback.answer()


@router.callback_query(F.data == "adnew")
async def advertisement_new(
    callback: CallbackQuery, state: FSMContext, admin_ids: set[int]
):
    if not allowed(callback, admin_ids, "ads"):
        return
    await state.set_state(AdvertisementForm.title)
    await callback.message.answer("Reklama sarlavhasini kiriting:")
    await callback.answer()


@router.message(AdvertisementForm.title)
async def advertisement_title(message: Message, state: FSMContext):
    await state.update_data(ad_title=message.text.strip())
    await state.set_state(AdvertisementForm.text)
    await message.answer("Reklama matnini kiriting:")


@router.message(AdvertisementForm.text)
async def advertisement_text(message: Message, state: FSMContext):
    await state.update_data(ad_text=message.text.strip())
    await state.set_state(AdvertisementForm.photo)
    await message.answer("Rasm yuboring yoki /skip:")


@router.message(AdvertisementForm.photo)
async def advertisement_save(message: Message, state: FSMContext, db: Database):
    if not message.photo and message.text != "/skip":
        return await message.answer("Rasm yoki /skip yuboring.")
    data = await state.get_data()
    ad_id = await db._execute(
        """INSERT INTO advertisements(title,text,photo_id,created_by)
           VALUES(?,?,?,?)""",
        (
            data["ad_title"],
            data["ad_text"],
            message.photo[-1].file_id if message.photo else None,
            message.from_user.id,
        ),
    )
    await log_action(db, message.from_user.id, "advertisement_created", "ad", ad_id)
    await state.clear()
    await message.answer(
        "✅ Reklama saqlandi. Tasodifiy ommaviy yuborishning oldini olish uchun "
        "tarqatish alohida tasdiqlanadi."
    )
