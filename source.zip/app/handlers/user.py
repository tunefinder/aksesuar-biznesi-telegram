from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.database import Database
from app.keyboards.common import contact_keyboard, main_menu
from app.keyboards.inline import (
    cart_keyboard,
    categories_keyboard,
    delivery_zones_keyboard,
    order_keyboard,
    payment_keyboard,
    promo_keyboard,
    product_keyboard,
    products_keyboard,
    variants_keyboard,
)
from app.services.orders import money, order_text
from app.states import Checkout

router = Router()


def cart_text(items):
    if not items:
        return "🛒 Savatingiz bo'sh. Katalogdan mahsulot tanlang."
    total = sum(item["price"] * item["quantity"] for item in items)
    lines = ["<b>🛒 Savatingiz</b>", ""]
    lines += [
        f"• {item['name']} × {item['quantity']} — {money(item['price'] * item['quantity'])}"
        for item in items
    ]
    return "\n".join(lines) + f"\n\n<b>Jami: {money(total)}</b>"


async def show_catalog(message: Message, db: Database):
    categories = await db.categories(parent_id=None, active_only=True)
    if not categories:
        await message.answer("Katalog hozircha bo'sh.")
        return
    await message.answer(
        "🛍 <b>Kategoriyani tanlang:</b>",
        reply_markup=categories_keyboard(categories),
    )


async def render_category(callback: CallbackQuery, db: Database, category_id: int):
    category = await db.category(category_id)
    if not category or not category["is_active"]:
        return await callback.answer("Kategoriya topilmadi.", show_alert=True)
    children = await db.categories(parent_id=category_id, active_only=True)
    products = await db.products_by_category(category_id)
    title = f"{category['emoji'] or '🗂'} <b>{category['name']}</b>"
    if category["description"]:
        title += f"\n\n{category['description']}"
    if children:
        title += "\n\nIchki kategoriyani tanlang:"
        markup = categories_keyboard(children, parent_id=category_id)
    else:
        title += "\n\n" + ("Mahsulotni tanlang:" if products else "Bu kategoriyada hozircha mahsulot yo'q.")
        markup = products_keyboard(products, category_id, bool(category["parent_id"]))
    if category["photo_id"]:
        await callback.message.answer_photo(category["photo_id"], caption=title, reply_markup=markup)
    else:
        await callback.message.edit_text(title, reply_markup=markup)
    await callback.answer()


@router.message(F.text == "/start")
async def start(message: Message, db: Database, admin_ids: set[int]):
    await db.register_user(
        message.from_user.id, message.from_user.full_name, message.from_user.username
    )
    await message.answer(
        "Assalomu alaykum! ✨\nAksesuarlar do'konimizga xush kelibsiz.",
        reply_markup=main_menu(message.from_user.id in admin_ids),
    )


@router.message(F.text == "🛍 Katalog")
async def catalog_message(message: Message, db: Database):
    await show_catalog(message, db)


@router.callback_query(F.data == "catalog")
async def catalog_callback(callback: CallbackQuery, db: Database):
    categories = await db.categories(parent_id=None, active_only=True)
    await callback.message.edit_text(
        "🛍 <b>Kategoriyani tanlang:</b>",
        reply_markup=categories_keyboard(categories),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("catback:"))
async def category_back(callback: CallbackQuery, db: Database):
    category = await db.category(int(callback.data.split(":")[1]))
    if category and category["parent_id"]:
        return await render_category(callback, db, category["parent_id"])
    await catalog_callback(callback, db)


@router.callback_query(F.data.startswith("cat:"))
async def category(callback: CallbackQuery, db: Database):
    await render_category(callback, db, int(callback.data.split(":")[1]))


@router.callback_query(F.data.startswith("product:"))
async def product(callback: CallbackQuery, db: Database):
    item = await db.product(int(callback.data.split(":")[1]))
    if not item:
        return await callback.answer("Mahsulot topilmadi", show_alert=True)
    caption = (
        f"<b>{item['name']}</b>\n\n{item['description']}\n\n"
        f"💳 <b>Narxi: {money(item['price'])}</b>"
    )
    variants = await db.variants(item["id"])
    markup = (
        variants_keyboard(variants, item["id"])
        if variants
        else product_keyboard(item["id"], item["category_id"])
    )
    if item["photo_id"]:
        await callback.message.answer_photo(item["photo_id"], caption=caption, reply_markup=markup)
    else:
        await callback.message.answer(caption, reply_markup=markup)
    await callback.answer()


@router.callback_query(F.data.startswith("addcart:"))
async def add_cart(callback: CallbackQuery, db: Database):
    await db.add_to_cart(callback.from_user.id, int(callback.data.split(":")[1]))
    await callback.answer("Savatga qo'shildi ✅")


@router.callback_query(F.data.startswith("variant:"))
async def add_variant_to_cart(callback: CallbackQuery, db: Database):
    variant = await db.variant(int(callback.data.split(":")[1]))
    if not variant or not variant["is_active"]:
        return await callback.answer("Variant topilmadi.", show_alert=True)
    if variant["stock"] <= 0:
        return await callback.answer("Bu variant omborda tugagan.", show_alert=True)
    await db.add_to_cart(callback.from_user.id, variant["product_id"], variant["id"])
    await callback.answer("Variant savatga qo‘shildi ✅")


@router.message(F.text == "🛒 Savatim")
async def cart(message: Message, db: Database):
    items = await db.cart(message.from_user.id)
    await message.answer(cart_text(items), reply_markup=cart_keyboard(items) if items else None)


@router.callback_query(F.data.startswith("remove:"))
async def remove_cart(callback: CallbackQuery, db: Database):
    parts = callback.data.split(":")
    variant_id = int(parts[2]) if len(parts) > 2 and parts[2] != "0" else None
    await db.remove_cart_item(callback.from_user.id, int(parts[1]), variant_id)
    items = await db.cart(callback.from_user.id)
    await callback.message.edit_text(
        cart_text(items), reply_markup=cart_keyboard(items) if items else None
    )
    await callback.answer("O'chirildi")


@router.callback_query(F.data == "checkout")
async def checkout(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Checkout.name)
    await callback.message.answer("Buyurtma uchun ismingizni kiriting:")
    await callback.answer()


@router.message(Checkout.name)
async def checkout_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(Checkout.phone)
    await message.answer(
        "Telefon raqamingizni yuboring yoki kiriting:", reply_markup=contact_keyboard()
    )


@router.message(Checkout.phone)
async def checkout_phone(message: Message, state: FSMContext):
    phone = message.contact.phone_number if message.contact else (message.text or "").strip()
    if len(phone) < 7:
        return await message.answer("Telefon raqamini to'g'ri kiriting.")
    await state.update_data(phone=phone)
    await state.set_state(Checkout.address)
    await message.answer("Yetkazib berish manzilini yozing:")


@router.message(Checkout.address)
async def checkout_address(message: Message, state: FSMContext, db: Database):
    await state.update_data(address=message.text.strip())
    zones = await db.delivery_zones()
    if zones:
        await state.set_state(Checkout.delivery)
        return await message.answer(
            "Yetkazib berish hududini tanlang:",
            reply_markup=delivery_zones_keyboard(zones),
        )
    await state.update_data(delivery_zone_id=None)
    await state.set_state(Checkout.promo)
    await message.answer(
        "Promokodingiz bo‘lsa kiriting:",
        reply_markup=promo_keyboard(),
    )


@router.callback_query(Checkout.delivery, F.data.startswith("checkoutzone:"))
async def checkout_zone(callback: CallbackQuery, state: FSMContext):
    await state.update_data(delivery_zone_id=int(callback.data.split(":")[1]))
    await state.set_state(Checkout.promo)
    await callback.message.answer(
        "Promokodingiz bo‘lsa kiriting:",
        reply_markup=promo_keyboard(),
    )
    await callback.answer()


@router.callback_query(Checkout.promo, F.data == "checkoutpromo:skip")
async def checkout_promo_skip(callback: CallbackQuery, state: FSMContext):
    await state.update_data(promo_code=None)
    await state.set_state(Checkout.payment)
    await callback.message.answer("To‘lov usulini tanlang:", reply_markup=payment_keyboard())
    await callback.answer()


@router.message(Checkout.promo)
async def checkout_promo(message: Message, state: FSMContext, db: Database):
    promo = await db.promo(message.text or "")
    if not promo:
        return await message.answer(
            "Promokod topilmadi yoki muddati tugagan. Qayta kiriting yoki o‘tkazing:",
            reply_markup=promo_keyboard(),
        )
    await state.update_data(promo_code=promo["code"])
    await state.set_state(Checkout.payment)
    await message.answer("✅ Promokod qabul qilindi.\nTo‘lov usulini tanlang:", reply_markup=payment_keyboard())


async def finish_order(
    event,
    user_id: int,
    state: FSMContext,
    db: Database,
    bot,
    admin_ids: set[int],
    payment_method: str,
):
    data = await state.get_data()
    try:
        result = await db.create_order(
            user_id,
            data["name"],
            data["phone"],
            data["address"],
            data.get("delivery_zone_id"),
            data.get("promo_code"),
            payment_method,
        )
    except ValueError as error:
        await state.clear()
        return await event.answer(f"❌ {error}")
    if not result:
        await state.clear()
        return await event.answer("Savatingiz bo‘sh ekan.")
    order, items = result
    if data.get("receipt_file_id"):
        await db._execute(
            "UPDATE payments SET receipt_file_id=? WHERE order_id=?",
            (data["receipt_file_id"], order["id"]),
        )
    text = order_text(order, items)
    for admin_id in admin_ids:
        await bot.send_message(admin_id, text, reply_markup=order_keyboard(order["id"]))
    await state.clear()
    await event.answer(
        f"✅ Buyurtmangiz qabul qilindi!\nRaqam: <b>{order['order_number']}</b>",
        reply_markup=main_menu(user_id in admin_ids),
    )


@router.callback_query(Checkout.payment, F.data.startswith("checkoutpay:"))
async def checkout_payment(
    callback: CallbackQuery,
    state: FSMContext,
    db: Database,
    bot,
    admin_ids: set[int],
):
    method = callback.data.split(":")[1]
    if method == "receipt":
        await state.update_data(payment_method=method)
        await state.set_state(Checkout.receipt)
        await callback.message.answer("To‘lov chekini rasm yoki hujjat shaklida yuboring:")
        return await callback.answer()
    await finish_order(
        callback.message, callback.from_user.id, state, db, bot, admin_ids, method
    )
    await callback.answer()


@router.message(Checkout.receipt)
async def checkout_receipt(
    message: Message,
    state: FSMContext,
    db: Database,
    bot,
    admin_ids: set[int],
):
    file_id = (
        message.photo[-1].file_id
        if message.photo
        else message.document.file_id if message.document else None
    )
    if not file_id:
        return await message.answer("Chek rasmini yoki hujjatini yuboring.")
    await state.update_data(receipt_file_id=file_id)
    await finish_order(
        message, message.from_user.id, state, db, bot, admin_ids, "receipt"
    )
