import asyncio
from pathlib import Path

import aiosqlite

from app.schema import migrate


class Database:
    def __init__(self, path: Path):
        self.path = path
        self._write_lock = asyncio.Lock()

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA synchronous=NORMAL")
            await db.execute("PRAGMA busy_timeout=10000")
            await migrate(db)
            await db.executemany(
                "INSERT OR IGNORE INTO categories(name, sort_order) VALUES(?, ?)",
                [
                    ("Soatlar", 10),
                    ("Zargarlik buyumlari", 20),
                    ("Sumkalar", 30),
                    ("Ko'zoynaklar", 40),
                ],
            )
            await db.commit()

    async def _fetchall(self, query, params=()):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("PRAGMA foreign_keys = ON")
            await db.execute("PRAGMA busy_timeout=10000")
            async with db.execute(query, params) as cursor:
                return await cursor.fetchall()

    async def _fetchone(self, query, params=()):
        rows = await self._fetchall(query, params)
        return rows[0] if rows else None

    async def _execute(self, query, params=()):
        async with self._write_lock:
            async with aiosqlite.connect(self.path) as db:
                await db.execute("PRAGMA foreign_keys = ON")
                await db.execute("PRAGMA busy_timeout=10000")
                cursor = await db.execute(query, params)
                await db.commit()
                return cursor.lastrowid

    async def categories(self, parent_id=None, active_only=True):
        where = ["parent_id IS ?" ]
        params = [parent_id]
        if active_only:
            where.append("is_active=1")
        return await self._fetchall(
            f"""SELECT c.*,
                       (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) product_count,
                       (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
                FROM categories c
                WHERE {' AND '.join(where)}
                ORDER BY sort_order, id""",
            params,
        )

    async def all_categories(self):
        return await self._fetchall(
            """SELECT c.*, p.name parent_name,
                      (SELECT COUNT(*) FROM products pr WHERE pr.category_id=c.id) product_count,
                      (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
               FROM categories c LEFT JOIN categories p ON p.id=c.parent_id
               ORDER BY COALESCE(c.parent_id, c.id), c.parent_id IS NOT NULL, c.sort_order, c.id"""
        )

    async def category(self, category_id: int):
        return await self._fetchone(
            """SELECT c.*, p.name parent_name,
                      (SELECT COUNT(*) FROM products pr WHERE pr.category_id=c.id) product_count,
                      (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id=c.id) child_count
               FROM categories c LEFT JOIN categories p ON p.id=c.parent_id
               WHERE c.id=?""",
            (category_id,),
        )

    async def add_category(self, name, description="", photo_id=None, emoji=None, parent_id=None):
        row = await self._fetchone(
            "SELECT COALESCE(MAX(sort_order), 0)+10 next_order FROM categories WHERE parent_id IS ?",
            (parent_id,),
        )
        return await self._execute(
            """INSERT INTO categories(name,description,photo_id,emoji,parent_id,sort_order)
               VALUES(?,?,?,?,?,?)""",
            (name.strip(), description.strip(), photo_id, emoji, parent_id, row["next_order"]),
        )

    async def update_category(self, category_id: int, field: str, value):
        allowed = {"name", "description", "photo_id", "emoji", "parent_id", "is_active"}
        if field not in allowed:
            raise ValueError("Noto'g'ri kategoriya maydoni")
        await self._execute(f"UPDATE categories SET {field}=? WHERE id=?", (value, category_id))

    async def toggle_category(self, category_id: int):
        await self._execute(
            "UPDATE categories SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",
            (category_id,),
        )

    async def move_category(self, category_id: int, direction: int):
        category = await self.category(category_id)
        if not category:
            return
        operator, order = ("<", "DESC") if direction < 0 else (">", "ASC")
        sibling = await self._fetchone(
            f"""SELECT * FROM categories WHERE parent_id IS ? AND sort_order {operator} ?
                ORDER BY sort_order {order}, id {order} LIMIT 1""",
            (category["parent_id"], category["sort_order"]),
        )
        if not sibling:
            return
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA busy_timeout=10000")
            await db.execute(
                "UPDATE categories SET sort_order=? WHERE id=?",
                (sibling["sort_order"], category_id),
            )
            await db.execute(
                "UPDATE categories SET sort_order=? WHERE id=?",
                (category["sort_order"], sibling["id"]),
            )
            await db.commit()

    async def delete_category(self, category_id: int, delete_products=False):
        category = await self.category(category_id)
        if not category:
            return False
        if category["child_count"]:
            raise ValueError("Ichki kategoriyalar mavjud")
        if category["product_count"] and not delete_products:
            raise ValueError("Mahsulotlar mavjud")
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            await db.execute("PRAGMA busy_timeout=10000")
            if delete_products:
                await db.execute("DELETE FROM products WHERE category_id=?", (category_id,))
            await db.execute("DELETE FROM categories WHERE id=?", (category_id,))
            await db.commit()
        return True

    async def products_by_category(self, category_id: int):
        return await self._fetchall(
            "SELECT * FROM products WHERE category_id=? ORDER BY id DESC", (category_id,)
        )

    async def products(self):
        return await self._fetchall(
            "SELECT p.*, c.name category_name FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC"
        )

    async def product(self, product_id: int):
        return await self._fetchone(
            "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?",
            (product_id,),
        )

    async def add_product(self, category_id: int, name: str, description: str, price: int, photo_id: str | None):
        await self._execute(
            "INSERT INTO products(category_id,name,description,price,photo_id) VALUES(?,?,?,?,?)",
            (category_id, name, description, price, photo_id),
        )

    async def update_product(self, product_id: int, field: str, value):
        allowed = {"name", "description", "price", "photo_id", "category_id"}
        if field not in allowed:
            raise ValueError("Noto'g'ri ustun")
        await self._execute(f"UPDATE products SET {field}=? WHERE id=?", (value, product_id))

    async def move_all_products(self, source_id: int, target_id: int):
        await self._execute(
            "UPDATE products SET category_id=? WHERE category_id=?", (target_id, source_id)
        )

    async def delete_product(self, product_id: int):
        await self._execute("DELETE FROM products WHERE id=?", (product_id,))

    async def add_to_cart(self, user_id: int, product_id: int, variant_id: int | None = None):
        existing = await self._fetchone(
            "SELECT 1 FROM cart_items WHERE user_id=? AND product_id=? AND variant_id IS ?",
            (user_id, product_id, variant_id),
        )
        if existing:
            await self._execute(
                """UPDATE cart_items SET quantity=quantity+1
                   WHERE user_id=? AND product_id=? AND variant_id IS ?""",
                (user_id, product_id, variant_id),
            )
        else:
            await self._execute(
                "INSERT INTO cart_items(user_id,product_id,variant_id,quantity) VALUES(?,?,?,1)",
                (user_id, product_id, variant_id),
            )

    async def cart(self, user_id: int):
        return await self._fetchall(
            """SELECT c.product_id,c.variant_id,c.quantity,p.name,
                      COALESCE(v.price,p.price) price,
                      TRIM(COALESCE(v.color,'') ||
                           CASE WHEN v.phone_model IS NOT NULL THEN ' · '||v.phone_model ELSE '' END) variant_name
               FROM cart_items c
               JOIN products p ON p.id=c.product_id
               LEFT JOIN product_variants v ON v.id=c.variant_id
               WHERE c.user_id=?""",
            (user_id,),
        )

    async def remove_cart_item(self, user_id: int, product_id: int, variant_id: int | None = None):
        await self._execute(
            "DELETE FROM cart_items WHERE user_id=? AND product_id=? AND variant_id IS ?",
            (user_id, product_id, variant_id),
        )

    async def create_order(
        self,
        user_id: int,
        name: str,
        phone: str,
        address: str,
        delivery_zone_id: int | None = None,
        promo_code: str | None = None,
        payment_method: str = "cash",
        bonus_to_use: int = 0,
    ):
        items = await self.cart(user_id)
        if not items:
            return None
        subtotal = sum(row["price"] * row["quantity"] for row in items)
        zone = (
            await self._fetchone("SELECT * FROM delivery_zones WHERE id=?", (delivery_zone_id,))
            if delivery_zone_id
            else None
        )
        delivery_fee = zone["price"] if zone else 0
        promo = await self.promo(promo_code) if promo_code else None
        from app.services.loyalty import calculate_discount

        discount = calculate_discount(promo, subtotal)
        customer = await self.user(user_id)
        bonus_used = min(max(0, bonus_to_use), customer["bonus_balance"] if customer else 0)
        total = max(0, subtotal + delivery_fee - discount - bonus_used)
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cursor = await db.execute(
                """INSERT INTO orders(
                   user_id,customer_name,phone,address,subtotal,delivery_fee,discount,
                   bonus_used,total,delivery_zone_id,promo_id,payment_method)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    user_id,
                    name,
                    phone,
                    address,
                    subtotal,
                    delivery_fee,
                    discount,
                    bonus_used,
                    total,
                    delivery_zone_id,
                    promo["id"] if promo else None,
                    payment_method,
                ),
            )
            order_id = cursor.lastrowid
            order_number = f"AX-{order_id:06d}"
            await db.execute(
                "UPDATE orders SET order_number=? WHERE id=?", (order_number, order_id)
            )
            await db.executemany(
                """INSERT INTO order_items(
                   order_id,product_id,variant_id,product_name,variant_name,price,quantity)
                   VALUES(?,?,?,?,?,?,?)""",
                [
                    (
                        order_id,
                        row["product_id"],
                        row["variant_id"],
                        row["name"],
                        row["variant_name"],
                        row["price"],
                        row["quantity"],
                    )
                    for row in items
                ],
            )
            for row in items:
                if row["variant_id"]:
                    changed = await db.execute(
                        """UPDATE product_variants SET stock=stock-?
                           WHERE id=? AND stock>=?""",
                        (row["quantity"], row["variant_id"], row["quantity"]),
                    )
                    if changed.rowcount != 1:
                        await db.rollback()
                        raise ValueError(f"{row['name']} omborda yetarli emas")
            await db.execute(
                "INSERT INTO payments(order_id,method,amount) VALUES(?,?,?)",
                (order_id, payment_method, total),
            )
            if promo:
                await db.execute(
                    "UPDATE promocodes SET used_count=used_count+1 WHERE id=?", (promo["id"],)
                )
                await db.execute(
                    "INSERT INTO promo_usages(promo_id,user_id,order_id) VALUES(?,?,?)",
                    (promo["id"], user_id, order_id),
                )
            if bonus_used:
                await db.execute(
                    "UPDATE users SET bonus_balance=bonus_balance-? WHERE telegram_id=?",
                    (bonus_used, user_id),
                )
                await db.execute(
                    """INSERT INTO bonus_transactions(user_id,amount,reason,order_id)
                       VALUES(?,?,?,?)""",
                    (user_id, -bonus_used, "Buyurtmada ishlatildi", order_id),
                )
            await db.execute("DELETE FROM cart_items WHERE user_id=?", (user_id,))
            await db.commit()
        return await self.order(order_id)

    async def order(self, order_id: int):
        order = await self._fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
        if not order:
            return None
        return order, await self._fetchall(
            "SELECT * FROM order_items WHERE order_id=?", (order_id,)
        )

    async def orders(self):
        return await self._fetchall("SELECT * FROM orders ORDER BY id DESC")

    async def set_order_status(self, order_id: int, status: str):
        await self._execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))

    async def award_order_bonus(self, order_id: int, percent: int = 2):
        order = await self._fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
        if not order:
            return 0
        existing = await self._fetchone(
            """SELECT 1 FROM bonus_transactions
               WHERE order_id=? AND reason='Buyurtma bonusi'""",
            (order_id,),
        )
        if existing:
            return 0
        amount = max(0, order["total"] * percent // 100)
        if not amount:
            return 0
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA busy_timeout=10000")
            await db.execute(
                "UPDATE users SET bonus_balance=bonus_balance+? WHERE telegram_id=?",
                (amount, order["user_id"]),
            )
            await db.execute(
                """INSERT INTO bonus_transactions(user_id,amount,reason,order_id)
                   VALUES(?,?,?,?)""",
                (order["user_id"], amount, "Buyurtma bonusi", order_id),
            )
            await db.commit()
        return amount

    async def register_user(self, user_id: int, full_name: str, username: str | None):
        referral_code = f"REF{user_id:X}"
        await self._execute(
            """INSERT INTO users(telegram_id,full_name,username,referral_code)
               VALUES(?,?,?,?)
               ON CONFLICT(telegram_id) DO UPDATE SET
                 full_name=excluded.full_name,username=excluded.username,
                 updated_at=CURRENT_TIMESTAMP""",
            (user_id, full_name, username, referral_code),
        )

    async def user(self, user_id: int):
        return await self._fetchone("SELECT * FROM users WHERE telegram_id=?", (user_id,))

    async def apply_referral(self, referred_id: int, referral_code: str, bonus: int = 5000):
        referrer = await self._fetchone(
            "SELECT telegram_id FROM users WHERE referral_code=?", (referral_code,)
        )
        if not referrer or referrer["telegram_id"] == referred_id:
            return False
        if await self._fetchone("SELECT 1 FROM referrals WHERE referred_id=?", (referred_id,)):
            return False
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA busy_timeout=10000")
            await db.execute(
                "INSERT INTO referrals(referrer_id,referred_id,bonus_awarded) VALUES(?,?,?)",
                (referrer["telegram_id"], referred_id, bonus),
            )
            await db.execute(
                "UPDATE users SET referred_by=?,bonus_balance=bonus_balance+? WHERE telegram_id=?",
                (referrer["telegram_id"], bonus, referred_id),
            )
            await db.execute(
                "UPDATE users SET bonus_balance=bonus_balance+? WHERE telegram_id=?",
                (bonus, referrer["telegram_id"]),
            )
            await db.executemany(
                "INSERT INTO bonus_transactions(user_id,amount,reason) VALUES(?,?,?)",
                [
                    (referred_id, bonus, "Referal orqali ro‘yxatdan o‘tish"),
                    (referrer["telegram_id"], bonus, "Yangi do‘st taklif qilindi"),
                ],
            )
            await db.commit()
        return True

    async def variants(self, product_id: int, active_only=True):
        condition = "AND is_active=1" if active_only else ""
        return await self._fetchall(
            f"SELECT * FROM product_variants WHERE product_id=? {condition} ORDER BY id",
            (product_id,),
        )

    async def variant(self, variant_id: int):
        return await self._fetchone(
            """SELECT v.*,p.name product_name FROM product_variants v
               JOIN products p ON p.id=v.product_id WHERE v.id=?""",
            (variant_id,),
        )

    async def add_variant(
        self,
        product_id: int,
        price: int,
        stock: int,
        color: str | None = None,
        phone_model: str | None = None,
        sku: str | None = None,
        attributes_json: str = "{}",
    ):
        return await self._execute(
            """INSERT INTO product_variants(product_id,sku,color,phone_model,attributes_json,price,stock)
               VALUES(?,?,?,?,?,?,?)""",
            (product_id, sku, color, phone_model, attributes_json, price, stock),
        )

    async def update_variant(self, variant_id: int, field: str, value):
        allowed = {"sku", "color", "phone_model", "attributes_json", "price", "stock", "is_active"}
        if field not in allowed:
            raise ValueError("Noto'g'ri variant maydoni")
        await self._execute(
            f"UPDATE product_variants SET {field}=? WHERE id=?", (value, variant_id)
        )

    async def search_products(
        self,
        query: str,
        category_id: int | None = None,
        min_price: int | None = None,
        max_price: int | None = None,
        in_stock: bool = False,
    ):
        where = ["p.is_active=1", "(p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)"]
        pattern = f"%{query.strip()}%"
        params: list = [pattern, pattern, pattern]
        if category_id:
            where.append("p.category_id=?")
            params.append(category_id)
        if min_price is not None:
            where.append("COALESCE(v.min_price,p.price)>=?")
            params.append(min_price)
        if max_price is not None:
            where.append("COALESCE(v.min_price,p.price)<=?")
            params.append(max_price)
        if in_stock:
            where.append("COALESCE(v.total_stock,0)>0")
        return await self._fetchall(
            f"""SELECT p.*,c.name category_name,COALESCE(v.min_price,p.price) display_price,
                       COALESCE(v.total_stock,0) total_stock
                FROM products p JOIN categories c ON c.id=p.category_id
                LEFT JOIN (
                    SELECT product_id,MIN(price) min_price,SUM(stock) total_stock
                    FROM product_variants WHERE is_active=1 GROUP BY product_id
                ) v ON v.product_id=p.id
                WHERE {' AND '.join(where)}
                ORDER BY p.id DESC LIMIT 50""",
            params,
        )

    async def toggle_favorite(self, user_id: int, product_id: int):
        exists = await self._fetchone(
            "SELECT 1 FROM favorites WHERE user_id=? AND product_id=?",
            (user_id, product_id),
        )
        if exists:
            await self._execute(
                "DELETE FROM favorites WHERE user_id=? AND product_id=?",
                (user_id, product_id),
            )
            return False
        await self._execute(
            "INSERT INTO favorites(user_id,product_id) VALUES(?,?)",
            (user_id, product_id),
        )
        return True

    async def favorites(self, user_id: int):
        return await self._fetchall(
            """SELECT p.*,c.name category_name FROM favorites f
               JOIN products p ON p.id=f.product_id
               JOIN categories c ON c.id=p.category_id
               WHERE f.user_id=? AND p.is_active=1 ORDER BY f.created_at DESC""",
            (user_id,),
        )

    async def user_orders(self, user_id: int):
        return await self._fetchall(
            "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 30", (user_id,)
        )

    async def delivery_zones(self, active_only=True):
        condition = "WHERE is_active=1" if active_only else ""
        return await self._fetchall(
            f"SELECT * FROM delivery_zones {condition} ORDER BY sort_order,id"
        )

    async def add_delivery_zone(self, name: str, price: int):
        return await self._execute(
            "INSERT INTO delivery_zones(name,price,sort_order) VALUES(?,?,(SELECT COALESCE(MAX(sort_order),0)+10 FROM delivery_zones))",
            (name.strip(), price),
        )

    async def promo(self, code: str):
        return await self._fetchone(
            """SELECT * FROM promocodes WHERE code=? COLLATE NOCASE AND is_active=1
               AND (starts_at IS NULL OR starts_at<=CURRENT_TIMESTAMP)
               AND (expires_at IS NULL OR expires_at>=CURRENT_TIMESTAMP)
               AND (usage_limit IS NULL OR used_count<usage_limit)""",
            (code.strip(),),
        )

    async def add_promo(
        self, code: str, discount_type: str, value: int, min_order=0, usage_limit=None
    ):
        return await self._execute(
            """INSERT INTO promocodes(code,discount_type,discount_value,min_order,usage_limit)
               VALUES(?,?,?,?,?)""",
            (code.upper().strip(), discount_type, value, min_order, usage_limit),
        )

    async def staff(self):
        return await self._fetchall(
            "SELECT * FROM staff_roles WHERE is_active=1 ORDER BY role,user_id"
        )

    async def set_role(self, user_id: int, role: str):
        await self._execute(
            """INSERT INTO staff_roles(user_id,role) VALUES(?,?)
               ON CONFLICT(user_id) DO UPDATE SET role=excluded.role,is_active=1""",
            (user_id, role),
        )

    async def audit(
        self, admin_id: int, action: str, entity_type=None, entity_id=None, details_json="{}"
    ):
        await self._execute(
            """INSERT INTO admin_actions(admin_id,action,entity_type,entity_id,details_json)
               VALUES(?,?,?,?,?)""",
            (admin_id, action, entity_type, str(entity_id) if entity_id is not None else None, details_json),
        )

    async def statistics(self):
        return {
            "orders": await self._fetchone(
                """SELECT COUNT(*) count,COALESCE(SUM(total),0) revenue,
                          COALESCE(AVG(total),0) average
                   FROM orders WHERE status!='Bekor qilindi'"""
            ),
            "customers": await self._fetchone("SELECT COUNT(*) count FROM users"),
            "products": await self._fetchone("SELECT COUNT(*) count FROM products"),
            "stock": await self._fetchone(
                "SELECT COALESCE(SUM(stock),0) units FROM product_variants"
            ),
            "top_products": await self._fetchall(
                """SELECT product_name,SUM(quantity) quantity,SUM(price*quantity) revenue
                   FROM order_items GROUP BY product_name ORDER BY quantity DESC LIMIT 10"""
            ),
        }
