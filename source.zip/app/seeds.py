import aiosqlite


CATEGORY_SEEDS = [
    ("Telefon aksessuarlari", "Telefon uchun zamonaviy va foydali aksessuarlar", "📱", None, 100),
    ("G‘iloflar", "Silikon, premium va himoyalovchi g‘iloflar", "🛡", "Telefon aksessuarlari", 110),
    ("Himoya oynalari", "Ekran va kamera uchun himoya oynalari", "✨", "Telefon aksessuarlari", 120),
    ("Zaryadlash", "Adapter, kabel, powerbank va simsiz zaryadlash", "🔌", "Telefon aksessuarlari", 130),
    ("Audio aksessuarlar", "Quloqchin, karnay va audio adapterlar", "🎧", None, 200),
    ("Smart soatlar", "Kundalik va sport uchun aqlli soatlar", "⌚", None, 300),
    ("Sumka va hamyonlar", "Shahar, sayohat va kundalik foydalanish uchun", "👜", None, 400),
    ("Ko‘zoynaklar", "Quyoshdan himoyalovchi zamonaviy modellar", "🕶", None, 500),
]


PRODUCT_SEEDS = [
    {
        "category": "G‘iloflar",
        "sku": "PROTO-CASE-MAGSAFE",
        "name": "MagSafe Premium g‘ilof",
        "description": "Kuchli magnit, yumshoq qoplama va kamera himoyasiga ega premium g‘ilof.",
        "brand": "Aksessuar Pro",
        "price": 89000,
        "variants": [
            ("CASE-IP15-BLK", "Qora", "iPhone 15 Pro", 99000, 18),
            ("CASE-IP15-BLU", "Ko‘k", "iPhone 15 Pro", 99000, 12),
            ("CASE-IP14-PNK", "Pushti", "iPhone 14", 89000, 9),
            ("CASE-S24-BLK", "Qora", "Samsung S24", 95000, 14),
        ],
    },
    {
        "category": "G‘iloflar",
        "sku": "PROTO-CASE-CLEAR",
        "name": "Shaffof Anti-Yellow g‘ilof",
        "description": "Sarg‘ayishga chidamli, zarbani yutuvchi shaffof himoya g‘ilofi.",
        "brand": "ClearGuard",
        "price": 49000,
        "variants": [
            ("CLEAR-IP15", "Shaffof", "iPhone 15", 55000, 25),
            ("CLEAR-S23", "Shaffof", "Samsung S23", 49000, 20),
            ("CLEAR-RN13", "Shaffof", "Redmi Note 13", 49000, 22),
        ],
    },
    {
        "category": "Himoya oynalari",
        "sku": "PROTO-GLASS-PRIVACY",
        "name": "Privacy 9D himoya oynasi",
        "description": "Yon tomondan ko‘rinishni cheklovchi, to‘liq ekranli 9D privacy oyna.",
        "brand": "GlassPro",
        "price": 59000,
        "variants": [
            ("GLASS-IP15P", None, "iPhone 15 Pro", 69000, 30),
            ("GLASS-S24", None, "Samsung S24", 65000, 24),
            ("GLASS-RN13", None, "Redmi Note 13", 59000, 28),
        ],
    },
    {
        "category": "Zaryadlash",
        "sku": "PROTO-CHARGER-20W",
        "name": "20W Fast Charge adapter",
        "description": "PD tezkor zaryadlash, qizib ketish va kuchlanishdan himoya.",
        "brand": "VoltX",
        "price": 149000,
        "variants": [
            ("CHG-20W-WHT", "Oq", "Type-C", 149000, 35),
            ("CHG-25W-BLK", "Qora", "Samsung 25W", 179000, 20),
        ],
    },
    {
        "category": "Zaryadlash",
        "sku": "PROTO-POWERBANK-10K",
        "name": "Powerbank 10 000 mAh",
        "description": "Ikki port, tezkor zaryadlash va raqamli quvvat indikatori.",
        "brand": "PowerGo",
        "price": 269000,
        "variants": [
            ("PB10-BLK", "Qora", None, 269000, 16),
            ("PB10-WHT", "Oq", None, 269000, 11),
            ("PB20-BLK", "Qora", "20 000 mAh", 399000, 8),
        ],
    },
    {
        "category": "Audio aksessuarlar",
        "sku": "PROTO-TWS-PRO",
        "name": "TWS Pro simsiz quloqchin",
        "description": "Shovqinni kamaytirish, sensor boshqaruv va 24 soatlik quvvat.",
        "brand": "SoundAir",
        "price": 299000,
        "variants": [
            ("TWS-PRO-WHT", "Oq", None, 299000, 21),
            ("TWS-PRO-BLK", "Qora", None, 319000, 17),
        ],
    },
    {
        "category": "Smart soatlar",
        "sku": "PROTO-WATCH-X8",
        "name": "Smart Watch X8 Ultra",
        "description": "Qo‘ng‘iroq, sport rejimlari, yurak urishi va uyqu monitoringi.",
        "brand": "TimeX",
        "price": 449000,
        "variants": [
            ("WATCH-X8-BLK", "Qora", "49 mm", 449000, 13),
            ("WATCH-X8-ORG", "To‘q sariq", "49 mm", 469000, 7),
            ("WATCH-X8-SLV", "Kumush", "49 mm", 479000, 10),
        ],
    },
    {
        "category": "Sumka va hamyonlar",
        "sku": "PROTO-BAG-CROSS",
        "name": "Urban Crossbody sumka",
        "description": "Suv o‘tkazmaydigan mato, yashirin cho‘ntak va USB chiqish.",
        "brand": "UrbanPack",
        "price": 239000,
        "variants": [
            ("BAG-CROSS-BLK", "Qora", None, 239000, 15),
            ("BAG-CROSS-GRY", "Kulrang", None, 239000, 9),
        ],
    },
    {
        "category": "Ko‘zoynaklar",
        "sku": "PROTO-GLASSES-POLAR",
        "name": "Polarized Classic ko‘zoynak",
        "description": "UV400 himoya va qutbli linzaga ega yengil klassik model.",
        "brand": "SunLine",
        "price": 189000,
        "variants": [
            ("SUN-POLAR-BLK", "Qora", None, 189000, 19),
            ("SUN-POLAR-BRN", "Jigarrang", None, 199000, 12),
        ],
    },
]


async def seed_prototype_catalog(db: aiosqlite.Connection) -> None:
    category_ids: dict[str, int] = {}
    for name, description, emoji, parent_name, sort_order in CATEGORY_SEEDS:
        parent_id = category_ids.get(parent_name) if parent_name else None
        await db.execute(
            """INSERT OR IGNORE INTO categories(
               name,description,emoji,parent_id,sort_order,is_active)
               VALUES(?,?,?,?,?,1)""",
            (name, description, emoji, parent_id, sort_order),
        )
        row = await (
            await db.execute("SELECT id FROM categories WHERE name=?", (name,))
        ).fetchone()
        category_ids[name] = row[0]

    for product in PRODUCT_SEEDS:
        row = await (
            await db.execute("SELECT id FROM products WHERE sku=?", (product["sku"],))
        ).fetchone()
        if row:
            product_id = row[0]
        else:
            cursor = await db.execute(
                """INSERT INTO products(
                   category_id,name,description,price,sku,brand,is_active)
                   VALUES(?,?,?,?,?,?,1)""",
                (
                    category_ids[product["category"]],
                    product["name"],
                    product["description"],
                    product["price"],
                    product["sku"],
                    product["brand"],
                ),
            )
            product_id = cursor.lastrowid

        for sku, color, phone_model, price, stock in product["variants"]:
            await db.execute(
                """INSERT OR IGNORE INTO product_variants(
                   product_id,sku,color,phone_model,price,stock,is_active)
                   VALUES(?,?,?,?,?,?,1)""",
                (product_id, sku, color, phone_model, price, stock),
            )
    await db.commit()
